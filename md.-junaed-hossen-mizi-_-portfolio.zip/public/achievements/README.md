# Academic achievement images are stored here
# Place your real documents/certificates in this directory:
# - ssc-marksheet.jpg
# - hsc-marksheet.jpg
# - board-scholarship.jpg
# - bba-result.jpg
# - hult-prize.jpg
# - world-bank-youth-summit.jpg
# - dse-training.jpg
# - proposal-prodigy.jpg
