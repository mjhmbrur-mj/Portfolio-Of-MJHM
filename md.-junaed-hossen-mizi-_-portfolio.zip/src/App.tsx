import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Currently } from './components/Currently';
import { About } from './components/About';
import { TheNumbers } from './components/TheNumbers';
import { Journey } from './components/Journey';
import { Education } from './components/Education';
import { AcademicInterests } from './components/AcademicInterests';
import { Skills } from './components/Skills';
import { Projects } from './components/Projects';
import { Research } from './components/Research';
import { Leadership } from './components/Leadership';
import { Achievements } from './components/Achievements';
import { Writing } from './components/Writing';
import { Certifications } from './components/Certifications';
import { CareerVision } from './components/CareerVision';
import { SocialImpact } from './components/SocialImpact';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { AcademicAchievementsPage } from './pages/AcademicAchievementsPage';

export default function App() {
  const [activeSection, setActiveSection] = useState<string>('home');
  const [currentPage, setCurrentPage] = useState<'home' | 'academics'>('home');

  // Handle URL hash changes for routing
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.toLowerCase();
      if (hash === '#academics' || hash === '#/academics') {
        setCurrentPage('academics');
      } else {
        setCurrentPage('home');
      }
    };

    // Check on initial load
    handleHashChange();

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const handleNavigate = (page: 'home' | 'academics') => {
    setCurrentPage(page);
    if (page === 'academics') {
      window.location.hash = '#academics';
    } else {
      window.location.hash = '#home';
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    if (currentPage !== 'home') return;

    const sections = [
      'home',
      'about',
      'numbers',
      'journey',
      'education',
      'academic-interests',
      'skills',
      'projects',
      'research',
      'leadership',
      'achievements',
      'writing',
      'certifications',
      'vision',
      'contact',
    ];

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      {
        rootMargin: '-20% 0px -60% 0px',
        threshold: 0,
      }
    );

    sections.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });

    return () => {
      sections.forEach((id) => {
        const el = document.getElementById(id);
        if (el) observer.unobserve(el);
      });
    };
  }, [currentPage]);

  if (currentPage === 'academics') {
    return (
      <div className="min-h-screen bg-white text-[#182033] flex flex-col selection:bg-[#3155D9] selection:text-white">
        <Navbar
          activeSection={activeSection}
          currentPage={currentPage}
          onNavigate={handleNavigate}
        />
        <AcademicAchievementsPage onBackToPortfolio={() => handleNavigate('home')} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white text-[#182033] flex flex-col selection:bg-[#3155D9] selection:text-white">
      {/* Sticky Top Navigation */}
      <Navbar
        activeSection={activeSection}
        currentPage={currentPage}
        onNavigate={handleNavigate}
      />

      {/* Main Page Sections */}
      <main className="flex-1">
        <Hero />
        <Currently />
        <About />
        <TheNumbers />
        <Journey />
        <Education onNavigateToAcademics={() => handleNavigate('academics')} />
        <AcademicInterests />
        <Skills />
        <Projects />
        <Research />
        <Leadership />
        <Achievements onNavigateToAcademics={() => handleNavigate('academics')} />
        <Writing />
        <Certifications />
        <CareerVision />
        <SocialImpact />
        <Contact />
      </main>

      {/* Site Footer */}
      <Footer />
    </div>
  );
}
