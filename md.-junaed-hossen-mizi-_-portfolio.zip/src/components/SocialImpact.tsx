import React from 'react';
import { socialImpactStatement } from '../data/portfolioData';

export const SocialImpact: React.FC = () => {
  return (
    <section className="py-20 md:py-24 bg-[#FAFBFF] text-[#182033] border-b border-[#E3E8F5] relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-12">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
            <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
              VALUES & PRINCIPLES
            </span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#182033]">
            {socialImpactStatement.heading}
          </h2>
          <p className="font-serif italic text-base sm:text-lg text-[#182033]/85 mt-4 leading-relaxed">
            "{socialImpactStatement.quote}"
          </p>
        </div>

        {/* 3 Core Impact Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {socialImpactStatement.pillars.map((pillar, idx) => (
            <div
              key={idx}
              className="p-7 rounded-2xl bg-white border border-[#E3E8F5] hover:border-[#3155D9] transition-all shadow-xs hover:shadow-lg hover:shadow-[#3155D9]/5 flex flex-col justify-between"
            >
              <div>
                <span className=" text-xs text-[#3155D9] font-semibold block mb-3">
                  Pillar 0{idx + 1}
                </span>
                <h3 className="font-serif text-lg font-bold text-[#182033]">
                  {pillar.title}
                </h3>
                <p className="font-sans text-xs sm:text-sm text-[#667085] mt-2 leading-relaxed">
                  {pillar.description}
                </p>
              </div>

              <div className="mt-5 pt-4 border-t border-[#E3E8F5] text-[11px]  text-[#667085]">
                <span>Domain Focus: <strong className="text-[#3155D9] font-medium">{pillar.metric}</strong></span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
