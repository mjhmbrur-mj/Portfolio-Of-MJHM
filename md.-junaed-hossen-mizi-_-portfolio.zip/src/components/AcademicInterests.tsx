import React, { useState } from 'react';
import { ArrowUpRight, Lightbulb } from 'lucide-react';
import { academicInterestsData } from '../data/portfolioData';

export const AcademicInterests: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All 14 Disciplines' },
    { id: 'core-finance', label: 'Core Corporate Finance' },
    { id: 'accounting-governance', label: 'Accounting & Governance' },
    { id: 'markets-strategy', label: 'Markets & Strategy' },
    { id: 'macro-research', label: 'Macro & Research' },
  ];

  const filteredTopics = selectedCategory === 'all'
    ? academicInterestsData
    : academicInterestsData.filter((t) => t.category === selectedCategory);

  return (
    <section id="academic-interests" className="py-20 md:py-28 bg-white text-[#182033] border-b border-[#E3E8F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
              <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
                INTELLECTUAL INQUIRY
              </span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#182033]">
              Areas of Exploration
            </h2>
            <p className="font-sans text-sm sm:text-base text-[#667085] mt-3 leading-relaxed">
              Curated domains across business administration, statutory accounting, economic institutions, and corporate finance that form my academic compass.
            </p>
          </div>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-lg text-xs  transition-all duration-200 cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-[#3155D9] text-white font-medium shadow-xs'
                    : 'bg-[#FAFBFF] text-[#667085] hover:text-[#182033] border border-[#E3E8F5]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredTopics.map((topic) => (
            <div
              key={topic.id}
              className="p-6 rounded-xl bg-white border border-[#E3E8F5] hover:border-[#3155D9] transition-all duration-150 shadow-xs hover:shadow-md hover:shadow-[#3155D9]/5 flex flex-col justify-between"
            >
              <div>
                {/* Category Chip & Index */}
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[11px]  text-[#3155D9] uppercase tracking-wider font-semibold bg-[#E9EEFF] px-2 py-0.5 rounded">
                    {topic.category.replace('-', ' ')}
                  </span>
                  <ArrowUpRight className="w-4 h-4 text-[#667085]" />
                </div>

                {/* Title */}
                <h3 className="font-serif text-lg font-bold text-[#182033]">
                  {topic.title}
                </h3>

                {/* Concise Summary */}
                <p className="font-sans text-xs text-[#667085] mt-2.5 leading-relaxed">
                  {topic.summary}
                </p>
              </div>

              {/* Why It Matters Callout */}
              <div className="mt-5 pt-4 border-t border-[#E3E8F5]">
                <div className="flex items-start gap-2">
                  <Lightbulb className="w-3.5 h-3.5 text-[#3155D9] shrink-0 mt-0.5" />
                  <p className="font-sans text-[11px] text-[#182033]/85 leading-normal italic">
                    "{topic.whyItMatters}"
                  </p>
                </div>

                {/* Related Concepts */}
                <div className="mt-3 flex flex-wrap gap-1">
                  {topic.relatedConcepts.map((concept, i) => (
                    <span
                      key={i}
                      className="text-[10px]  px-1.5 py-0.5 rounded bg-[#FAFBFF] text-[#667085] border border-[#E3E8F5]"
                    >
                      {concept}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
