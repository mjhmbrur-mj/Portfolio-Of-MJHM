import React, { useState } from 'react';
import { CheckCircle2 } from 'lucide-react';
import { careerRoadmapData } from '../data/portfolioData';

export const CareerVision: React.FC = () => {
  const [activePhase, setActivePhase] = useState<number>(1);

  const futureRoles = [
    { title: "Financial Analyst", timing: "Near-Term Horizon" },
    { title: "Investment Professional", timing: "Professional Track" },
    { title: "Chartered Accountant (CA)", timing: "Credential Goal" },
    { title: "Empirical Researcher", timing: "Graduate Track" },
    { title: "Corporate Finance Lead", timing: "Mid-Career" },
    { title: "Chief Financial Officer (CFO)", timing: "Long-term Strategic Aspiration" },
  ];

  return (
    <section id="vision" className="py-20 md:py-28 bg-white text-[#182033] border-b border-[#E3E8F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-12">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
            <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
              TRAJECTORY & HORIZON
            </span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#182033]">
            Where I'm Going
          </h2>
          <p className="font-sans text-sm sm:text-base text-[#667085] mt-3 leading-relaxed italic">
            "My current goal is to build a rigorous foundation in corporate finance, statutory accounting, empirical research, and leadership. Over time, I want to convert that foundation into professional expertise, pursue advanced studies, and undertake strategic leadership responsibilities in financial institutions."
          </p>
        </div>

        {/* Career Roadmap Stepper */}
        <div className="mb-14">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-serif text-xl font-bold text-[#182033]">
              The Long-Range Roadmap
            </h3>
            <span className=" text-xs text-[#3155D9] font-semibold">
              Phase 0{activePhase} of 05
            </span>
          </div>

          {/* Stepper buttons */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 mb-5">
            {careerRoadmapData.map((step) => {
              const isSelected = activePhase === step.phase;
              return (
                <button
                  key={step.phase}
                  type="button"
                  onClick={() => setActivePhase(step.phase)}
                  className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#3155D9] text-white border-[#3155D9] shadow-md shadow-[#3155D9]/20'
                      : 'bg-[#FAFBFF] text-[#182033] border-[#E3E8F5] hover:border-[#3155D9]'
                  }`}
                >
                  <div className={`flex items-center justify-between text-[10px]  mb-1 ${
                    isSelected ? 'text-white/80' : 'text-[#667085]'
                  }`}>
                    <span>Phase 0{step.phase}</span>
                    <span className="uppercase font-semibold">{step.status}</span>
                  </div>
                  <h4 className="font-serif text-xs font-bold truncate">
                    {step.title}
                  </h4>
                  <span className={`text-[10px]  mt-0.5 block ${
                    isSelected ? 'text-white/80' : 'text-[#667085]'
                  }`}>
                    {step.timeframe}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Active Phase Card */}
          {(() => {
            const step = careerRoadmapData.find((s) => s.phase === activePhase) || careerRoadmapData[0];
            return (
              <div className="p-6 sm:p-8 rounded-2xl bg-[#FAFBFF] border border-[#E3E8F5] shadow-xs">
                <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 pb-4 mb-4 border-b border-[#E3E8F5]">
                  <div>
                    <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
                      Phase 0{step.phase} • {step.timeframe}
                    </span>
                    <h4 className="font-serif text-2xl font-bold text-[#182033] mt-1">
                      {step.title}
                    </h4>
                  </div>
                  <span className=" text-xs px-2.5 py-1 rounded-md bg-[#E9EEFF] text-[#3155D9] border border-[#3155D9]/20 font-semibold">
                    Status: {step.status.toUpperCase()}
                  </span>
                </div>

                <p className="font-sans text-xs sm:text-sm text-[#667085] leading-relaxed mb-5">
                  {step.focus}
                </p>

                <div className="space-y-2">
                  <h5 className=" text-xs uppercase tracking-wider text-[#667085] font-semibold mb-2">
                    Milestones
                  </h5>
                  {step.milestones.map((milestone, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 font-sans text-xs text-[#182033]/90">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#3155D9] shrink-0 mt-0.5" />
                      <span>{milestone}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}
        </div>

        {/* Future Roles Trajectories */}
        <div className="p-6 sm:p-8 rounded-2xl bg-[#FAFBFF] border border-[#E3E8F5]">
          <h3 className="font-serif text-lg font-bold text-[#182033] mb-1">
            Target Trajectories
          </h3>
          <p className="font-sans text-xs text-[#667085] mb-5">
            Recognizing that executive roles such as CFO represent long-term destinations nurtured by years of technical discipline.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {futureRoles.map((role, i) => (
              <div
                key={i}
                className="p-3.5 rounded-xl bg-white border border-[#E3E8F5] shadow-2xs hover:border-[#3155D9] transition-colors"
              >
                <span className="font-serif text-xs font-bold text-[#182033] block leading-tight">{role.title}</span>
                <span className=" text-[10px] text-[#3155D9] font-medium block mt-1.5">{role.timing}</span>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
