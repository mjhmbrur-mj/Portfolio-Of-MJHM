import React from 'react';
import { X, Clock, CheckCircle2 } from 'lucide-react';
import { LabArticle } from '../types';

interface ArticleReaderModalProps {
  article: LabArticle | null;
  onClose: () => void;
}

export const ArticleReaderModal: React.FC<ArticleReaderModalProps> = ({ article, onClose }) => {
  if (!article) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-[#182033]/60 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Modal Container */}
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl bg-white border border-[#E3E8F5] shadow-2xl p-6 sm:p-8 z-10 text-[#182033]">
        
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-[#FAFBFF] text-[#667085] hover:text-[#182033] border border-[#E3E8F5] hover:border-[#3155D9] transition-colors cursor-pointer"
          aria-label="Close reader"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Top Badges */}
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <span className="px-2.5 py-0.5 rounded-md text-xs  bg-[#E9EEFF] text-[#3155D9] border border-[#3155D9]/20 font-semibold">
            {article.status}
          </span>
          <span className="text-xs  text-[#667085] bg-[#FAFBFF] px-2.5 py-0.5 rounded-md border border-[#E3E8F5]">
            {article.topic}
          </span>
          <span className="text-xs  text-[#667085] flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-[#3155D9]" />
            {article.readTime}
          </span>
        </div>

        {/* Title */}
        <h2 className="font-serif text-2xl sm:text-3xl font-bold tracking-tight text-[#182033] leading-tight">
          {article.title}
        </h2>
        <p className="text-xs text-[#3155D9]  mt-1 font-medium">
          By Md. Junaed Hossen Mizi • Junaed's Finance Lab
        </p>

        {/* Article Summary */}
        <div className="my-5 p-4 rounded-xl bg-[#FAFBFF] border border-[#E3E8F5] text-sm text-[#182033]/85 leading-relaxed font-sans">
          {article.summary}
        </div>

        {/* Executive Takeaways */}
        <div className="my-5">
          <h3 className="text-xs  uppercase tracking-wider text-[#3155D9] font-semibold mb-2.5">
            Core Analytical Takeaways
          </h3>
          <div className="space-y-2">
            {article.executiveTakeaways.map((takeaway, idx) => (
              <div
                key={idx}
                className="p-3 rounded-lg bg-[#FAFBFF] border border-[#E3E8F5] flex items-start gap-2.5 text-xs sm:text-sm text-[#182033] font-sans"
              >
                <CheckCircle2 className="w-4 h-4 text-[#3155D9] shrink-0 mt-0.5" />
                <span className="leading-relaxed">{takeaway}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Detailed Outline */}
        <div className="my-5 p-4 rounded-xl bg-[#FAFBFF] border border-[#E3E8F5]">
          <h4 className="text-xs  uppercase tracking-wider text-[#667085] mb-1.5 font-semibold">
            Framework & Scope
          </h4>
          <p className="text-xs text-[#667085] leading-relaxed font-sans">
            {article.fullOutline}
          </p>
        </div>

        {/* Status Callout */}
        <div className="mt-6 pt-4 border-t border-[#E3E8F5] flex items-center justify-between text-xs text-[#667085] ">
          <span>Junaed's Finance Lab</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-[#3155D9] hover:bg-[#2444B8] text-white font-medium transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
