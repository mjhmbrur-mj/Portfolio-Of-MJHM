import React, { useState } from 'react';
import { theNumbersData } from '../data/portfolioData';

export const TheNumbers: React.FC = () => {
  const [activeMetric, setActiveMetric] = useState<string | null>(null);

  return (
    <section id="numbers" className="py-20 md:py-24 bg-[#E9EEFF] border-b border-[#E3E8F5] text-[#182033]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-baseline justify-between gap-6 mb-14">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
              <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
                QUANTITATIVE RECORD
              </span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#182033]">
              The Numbers.
            </h2>
            <p className="font-sans text-sm sm:text-base text-[#667085] mt-3">
              Academic metrics and institutional milestones that document academic consistency and sustained pursuit of excellence.
            </p>
          </div>

          <div className=" text-xs text-[#3155D9] border border-[#3155D9]/30 px-3.5 py-1.5 rounded-lg bg-white shadow-xs font-medium">
            <span>Govt. Board Scholarship Recipient</span>
          </div>
        </div>

        {/* The 6 Metrics Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {theNumbersData.map((item) => {
            const isSelected = activeMetric === item.id;
            return (
              <div
                key={item.id}
                onMouseEnter={() => setActiveMetric(item.id)}
                onMouseLeave={() => setActiveMetric(null)}
                className={`p-6 rounded-xl transition-all duration-150 border bg-white shadow-xs ${
                  isSelected
                    ? 'border-[#3155D9] shadow-md shadow-[#3155D9]/10'
                    : 'border-[#E3E8F5] hover:border-[#3155D9]/50'
                }`}
              >
                {/* Top tag */}
                <div className="flex items-center justify-between mb-3">
                  <span className=" text-[11px] uppercase tracking-wider text-[#3155D9] font-medium bg-[#E9EEFF] px-2 py-0.5 rounded">
                    {item.tag}
                  </span>
                </div>

                {/* Big Number Display in Aptos */}
                <div className="flex items-baseline gap-1 mb-2">
                  <span className="text-3xl sm:text-4xl font-bold tracking-tight text-[#182033]">
                    {item.value}
                  </span>
                  {item.suffix && (
                    <span className="text-lg text-[#3155D9] font-semibold">
                      {item.suffix}
                    </span>
                  )}
                </div>

                {/* Metric Label */}
                <h3 className="text-sm font-bold text-[#182033]">
                  {item.label}
                </h3>
                <p className="text-xs text-[#667085] mt-0.5">
                  {item.sublabel}
                </p>

                {/* Context description */}
                <p className="font-sans text-xs text-[#667085] mt-3.5 leading-relaxed pt-3 border-t border-[#E3E8F5]">
                  {item.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Institutional Verification Note */}
        <div className="mt-10 p-4 rounded-xl bg-white border border-[#E3E8F5] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-[#667085]  shadow-xs">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#3155D9]" />
            <span className="text-[#182033]">Transcripts and credentials issued by Begum Rokeya University & Dinajpur Education Board.</span>
          </div>
          <span className="text-[#3155D9] font-medium">Dept. of Finance & Banking</span>
        </div>

      </div>
    </section>
  );
};
