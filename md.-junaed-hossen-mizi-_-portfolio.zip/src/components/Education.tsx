import React from 'react';
import { Award, ArrowUpRight } from 'lucide-react';
import { educationData } from '../data/portfolioData';

interface EducationProps {
  onNavigateToAcademics?: () => void;
}

export const Education: React.FC<EducationProps> = ({ onNavigateToAcademics }) => {
  return (
    <section id="education" className="py-20 md:py-28 bg-[#E9EEFF] text-[#182033] border-b border-[#E3E8F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-14">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
            <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
              ACADEMIC & PROFESSIONAL EDUCATION
            </span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#182033]">
            Education & Qualifications
          </h2>
          <p className="font-sans text-sm sm:text-base text-[#667085] mt-3">
            Combining undergraduate university studies in finance with formal chartered accountancy preparation under Bangladesh's premier professional institute.
          </p>
        </div>

        {/* Education Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-7 items-stretch">
          
          {/* Card 1: BBA in Finance & Banking */}
          <div className="p-7 rounded-2xl bg-white border border-[#E3E8F5] shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <span className=" text-xs text-[#3155D9] px-2.5 py-0.5 rounded-md bg-[#E9EEFF] border border-[#3155D9]/20 font-semibold">
                  Undergraduate Degree
                </span>
                <span className=" text-xs text-[#667085]">
                  2022–2023 Session
                </span>
              </div>

              <h3 className="font-serif text-2xl font-bold text-[#182033] tracking-tight">
                Bachelor of Business Administration (BBA)
              </h3>
              <p className="font-sans text-sm font-semibold text-[#3155D9] mt-1">
                Major in Finance and Banking
              </p>
              <p className="font-sans text-sm text-[#667085] mt-0.5">
                Begum Rokeya University, Rangpur (BRUR)
              </p>

              {/* Metric Highlights */}
              <div className="grid grid-cols-2 gap-3 my-5 p-3.5 rounded-xl bg-[#FAFBFF] border border-[#E3E8F5]">
                <div>
                  <span className="block  text-[11px] text-[#667085]">Current CGPA</span>
                  <span className=" text-xl font-bold text-[#182033]">3.67 / 4.00</span>
                  <span className="block  text-[11px] text-[#3155D9] mt-0.5 font-medium">SGPA 3.71 Recent Term</span>
                </div>
                <div>
                  <span className="block  text-[11px] text-[#667085]">Expected Graduation</span>
                  <span className=" text-xl font-bold text-[#182033]">2027</span>
                  <span className="block  text-[11px] text-[#667085] mt-0.5">15th Batch</span>
                </div>
              </div>

              <p className="font-sans text-xs sm:text-sm text-[#667085] leading-relaxed">
                Comprehensive coursework in corporate finance, financial statement analysis, commercial banking, portfolio theory, and statistical modeling.
              </p>

              {/* Key Courses */}
              <div className="mt-5">
                <h4 className=" text-xs uppercase tracking-wider text-[#667085] mb-2 font-medium">
                  Specialized Coursework
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    "Corporate Finance",
                    "Financial Statement Analysis",
                    "Commercial Banking & Regulations",
                    "Investment & Portfolio Analysis",
                    "Quantitative Methods & Statistics",
                    "Managerial Economics",
                  ].map((course, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded text-xs font-sans bg-[#FAFBFF] border border-[#E3E8F5] text-[#182033]"
                    >
                      {course}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Distinction note */}
            <div className="mt-6 pt-4 border-t border-[#E3E8F5] flex items-center gap-2  text-xs text-[#182033]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#3155D9]" />
              <span className="font-medium">Elected Class Representative (15th Batch, BRUR)</span>
            </div>
          </div>

          {/* Card 2: Professional ICAB CA Qualification */}
          <div className="p-7 rounded-2xl bg-white border border-[#E3E8F5] shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <span className=" text-xs text-[#3155D9] px-2.5 py-0.5 rounded-md bg-[#E9EEFF] border border-[#3155D9]/20 font-semibold">
                  Professional Qualification Track
                </span>
                <span className=" text-xs text-[#667085]">
                  2026 – In Progress
                </span>
              </div>

              <h3 className="font-serif text-2xl font-bold text-[#182033] tracking-tight">
                Chartered Accountancy (CA)
              </h3>
              <p className="font-sans text-sm font-semibold text-[#3155D9] mt-1">
                Certificate Level Student
              </p>
              <p className="font-sans text-sm text-[#667085] mt-0.5">
                Institute of Chartered Accountants of Bangladesh (ICAB)
              </p>

              {/* Status Note */}
              <div className="my-5 p-3.5 rounded-xl bg-[#FAFBFF] border border-[#E3E8F5]">
                <span className="block  text-xs font-semibold text-[#182033]">
                  Professional Qualification In Progress
                </span>
                <p className="font-sans text-xs text-[#667085] mt-1 leading-relaxed">
                  Actively studying foundational professional papers under ICAB. Clear distinction maintained between university degree studies and professional CA certification.
                </p>
              </div>

              <p className="font-sans text-xs sm:text-sm text-[#667085] leading-relaxed">
                Developing technical audit, corporate tax, and accounting competencies aligned with international reporting standards (IFRS/IAS).
              </p>

              {/* Core Syllabus Modules */}
              <div className="mt-5">
                <h4 className=" text-xs uppercase tracking-wider text-[#667085] mb-2 font-medium">
                  Certificate Level Subject Domains
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    "Financial Accounting (IFRS)",
                    "Assurance & Audit Fundamentals",
                    "Principles of Taxation",
                    "Business Law & Ethics",
                    "Management Information",
                  ].map((subject, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded text-xs font-sans bg-[#FAFBFF] border border-[#E3E8F5] text-[#182033]"
                    >
                      {subject}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Credential integrity note */}
            <div className="mt-6 pt-4 border-t border-[#E3E8F5] flex items-center gap-2  text-xs text-[#667085]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#3155D9]" />
              <span className="text-[#3155D9] font-medium">Building towards future Chartered Accountant credentials</span>
            </div>
          </div>

        </div>

        {/* Card 3: Academic Foundation & Board Scholarship Banner */}
        <div className="mt-7 p-6 sm:p-7 rounded-2xl bg-white border border-[#E3E8F5] shadow-xs">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
            
            <div className="md:col-span-8">
              <span className=" text-xs text-[#3155D9] font-semibold block mb-1">
                PRE-UNIVERSITY ACADEMIC DISTINCTION
              </span>
              <h3 className="font-serif text-xl sm:text-2xl font-bold text-[#182033]">
                Secondary & Higher Secondary Distinctions
              </h3>
              <p className="font-sans text-xs sm:text-sm text-[#667085] mt-1.5 leading-relaxed">
                Awarded maximum GPA 5.00 in both Secondary School Certificate (SSC) and Higher Secondary Certificate (HSC) nationwide examinations, alongside an official Government Board Scholarship recognizing regional scholastic standing.
              </p>
            </div>

            <div className="md:col-span-4 flex flex-col sm:flex-row md:flex-col gap-2.5 justify-center">
              <div className="p-3 rounded-xl bg-[#FAFBFF] border border-[#E3E8F5] flex items-center justify-between">
                <div>
                  <span className="block  text-[11px] text-[#667085]">SSC Examination</span>
                  <span className=" text-sm font-semibold text-[#182033]">GPA 5.00 / 5.00</span>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px]  bg-[#E9EEFF] text-[#3155D9] border border-[#3155D9]/20 font-medium">
                  Golden GPA
                </span>
              </div>

              <div className="p-3 rounded-xl bg-[#FAFBFF] border border-[#E3E8F5] flex items-center justify-between">
                <div>
                  <span className="block  text-[11px] text-[#667085]">HSC Examination</span>
                  <span className=" text-sm font-semibold text-[#182033]">GPA 5.00 / 5.00</span>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px]  bg-[#E9EEFF] text-[#3155D9] border border-[#3155D9]/20 font-medium">
                  Golden GPA
                </span>
              </div>

              <div className="p-3 rounded-xl bg-[#FAFBFF] border border-[#E3E8F5] flex items-center justify-between">
                <div>
                  <span className="block  text-[11px] text-[#667085]">Merit Award</span>
                  <span className="font-sans text-xs font-bold text-[#182033]">Govt. Board Scholarship</span>
                </div>
                <Award className="w-4 h-4 text-[#3155D9] shrink-0" />
              </div>
            </div>

          </div>
        </div>

        {/* Dedicated Academic Achievements Dossier Banner (NO BLACK BACKGROUND) */}
        {onNavigateToAcademics && (
          <div className="mt-6 p-6 rounded-2xl bg-white border-2 border-[#3155D9]/30 text-[#182033] shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
                <span className=" text-xs text-[#3155D9] font-semibold uppercase">ACADEMIC ACHIEVEMENTS ARCHIVE</span>
              </div>
              <h4 className="font-serif text-lg font-bold text-[#182033]">
                Course grades & original academic documents archive
              </h4>
              <p className="font-sans text-xs text-[#667085] mt-0.5">
                Explore the dedicated Academic Achievements dossier featuring verified marksheets, certificates, and semester breakdowns.
              </p>
            </div>

            <button
              type="button"
              onClick={onNavigateToAcademics}
              className="px-5 py-2.5 rounded-lg bg-[#3155D9] hover:bg-[#2444B8] text-white font-sans text-xs font-medium inline-flex items-center gap-2 transition-colors shrink-0 cursor-pointer shadow-sm shadow-[#3155D9]/20"
            >
              <span>View Academic Archive</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

      </div>
    </section>
  );
};
