import React from 'react';
import { Award, CheckCircle2, Briefcase, HeartHandshake, TreePine } from 'lucide-react';

export const Leadership: React.FC = () => {
  return (
    <section id="leadership" className="py-20 md:py-28 bg-[#FAFBFF] text-[#182033] border-b border-[#E3E8F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-12">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
            <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
              STEWARDSHIP & RESPONSIBILITY
            </span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#182033]">
            Leadership & Campus Engagement
          </h2>
          <p className="font-sans text-sm sm:text-base text-[#667085] mt-3 leading-relaxed">
            Leading with empathy, reliability, and structured communication—from serving 60+ classmates as Class Representative to structuring competitive venture financials.
          </p>
        </div>

        {/* Leadership Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
          
          {/* Card 1: Class Representative */}
          <div className="p-8 rounded-2xl bg-white border border-[#E3E8F5] hover:border-[#3155D9] transition-all shadow-xs hover:shadow-lg hover:shadow-[#3155D9]/5 relative">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <span className="px-3 py-1 rounded-md text-xs  bg-[#E9EEFF] text-[#3155D9] border border-[#3155D9]/20 font-semibold">
                Elected Cohort Leader
              </span>
              <span className="text-xs  text-[#667085]">
                15th Batch (2022–2023)
              </span>
            </div>

            <h3 className="font-serif text-2xl font-bold text-[#182033]">
              Class Representative (CR)
            </h3>
            <p className="font-sans text-xs font-semibold text-[#3155D9] mt-1">
              Department of Finance and Banking, BRUR
            </p>

            <p className="font-sans text-xs sm:text-sm text-[#667085] mt-3 leading-relaxed">
              Official liaison between faculty members, departmental leadership, and a cohort of 60+ classmates. Coordinated schedules, academic resources, and peer support.
            </p>

            {/* Core Responsibilities */}
            <div className="mt-6 pt-5 border-t border-[#E3E8F5]">
              <h4 className=" text-xs uppercase tracking-wider text-[#667085] font-semibold mb-3">
                Key Responsibilities
              </h4>
              <ul className="space-y-2 font-sans">
                {[
                  "Maintaining daily direct liaison between academic faculty and student body",
                  "Coordinating lecture rescheduling, examination venues, and semester timetables",
                  "Organizing collaborative peer review groups and academic materials distribution",
                  "Supporting classmates through academic uncertainties and cohort welfare",
                ].map((resp, i) => (
                  <li key={i} className="text-xs text-[#182033]/85 flex items-start gap-2.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#3155D9] shrink-0 mt-0.5" />
                    <span>{resp}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Card 2: CFO — Haatkotha / Hult Prize BRUR */}
          <div className="p-8 rounded-2xl bg-white border border-[#E3E8F5] hover:border-[#3155D9] transition-all shadow-xs hover:shadow-lg hover:shadow-[#3155D9]/5 relative">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <span className="px-3 py-1 rounded-md text-xs  bg-[#E9EEFF] text-[#3155D9] border border-[#3155D9]/20 font-semibold flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5" />
                1st Runner-Up Distinction
              </span>
              <span className="text-xs  text-[#667085]">
                Hult Prize BRUR
              </span>
            </div>

            <h3 className="font-serif text-2xl font-bold text-[#182033]">
              Chief Financial Officer (CFO) — Haatkotha
            </h3>
            <p className="font-sans text-xs font-semibold text-[#3155D9] mt-1">
              Social-Commerce Venture Pitch
            </p>

            <p className="font-sans text-xs sm:text-sm text-[#667085] mt-3 leading-relaxed">
              Spearheaded commercial viability, unit economics, working capital requirements, and investor pitching for the artisan venture 'Haatkotha', placing second overall in campus finals.
            </p>

            {/* CFO Contributions */}
            <div className="mt-6 pt-5 border-t border-[#E3E8F5]">
              <h4 className=" text-xs uppercase tracking-wider text-[#667085] font-semibold mb-3">
                Financial Architecture
              </h4>
              <ul className="space-y-2 font-sans">
                {[
                  "Modeled a BDT 5 Lakh seed deployment across 5 core operational expenditure buckets",
                  "Forecasted break-even cash flows and unit customer acquisition economics",
                  "Defended financial model assumptions before adjudicators and faculty judges",
                  "Structured fair compensation frameworks safeguarding artisan margins",
                ].map((resp, i) => (
                  <li key={i} className="text-xs text-[#182033]/85 flex items-start gap-2.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#3155D9] shrink-0 mt-0.5" />
                    <span>{resp}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

        </div>

        {/* Additional Student Organizations */}
        <div className="mt-10 pt-8 border-t border-[#E3E8F5]">
          <h3 className="font-serif text-xl font-bold text-[#182033] mb-6">
            Institutional Organizations & Engagement
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Career Network */}
            <div className="p-6 rounded-2xl bg-white border border-[#E3E8F5] shadow-xs">
              <Briefcase className="w-4 h-4 text-[#3155D9] mb-3" />
              <h4 className="font-serif text-base font-bold text-[#182033]">
                Career Network BRUR
              </h4>
              <p className=" text-[11px] text-[#3155D9] font-medium mt-0.5">
                Active Member & Organizer
              </p>
              <p className="font-sans text-xs text-[#667085] mt-2 leading-relaxed">
                Contributing to corporate speaker sessions, resume workshops, and encouraging finance undergraduates in national competitions.
              </p>
            </div>

            {/* Chandpur District Welfare */}
            <div className="p-6 rounded-2xl bg-white border border-[#E3E8F5] shadow-xs">
              <HeartHandshake className="w-4 h-4 text-[#3155D9] mb-3" />
              <h4 className="font-serif text-base font-bold text-[#182033]">
                Chandpur District Student Welfare
              </h4>
              <p className=" text-[11px] text-[#3155D9] font-medium mt-0.5">
                Executive Contributor
              </p>
              <p className="font-sans text-xs text-[#667085] mt-2 leading-relaxed">
                Supporting incoming students from Chandpur district with university orientation, housing guidance, and regional community.
              </p>
            </div>

            {/* Green Voice BRUR */}
            <div className="p-6 rounded-2xl bg-white border border-[#E3E8F5] shadow-xs">
              <TreePine className="w-4 h-4 text-[#3155D9] mb-3" />
              <h4 className="font-serif text-base font-bold text-[#182033]">
                Green Voice BRUR
              </h4>
              <p className=" text-[11px] text-[#3155D9] font-medium mt-0.5">
                Campus Volunteer
              </p>
              <p className="font-sans text-xs text-[#667085] mt-2 leading-relaxed">
                Participating in environmental awareness initiatives, sustainability dialogues, and campus green drives.
              </p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
