import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { timelineData } from '../data/portfolioData';

export const Journey: React.FC = () => {
  const [selectedItem, setSelectedItem] = useState<string>(timelineData[3].id); // 2026 default
  const [expandedItems, setExpandedItems] = useState<Record<string, boolean>>({
    '2026': true,
    '2025': true,
  });

  const toggleExpand = (id: string) => {
    setExpandedItems((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  return (
    <section id="journey" className="py-20 md:py-28 bg-[#E9EEFF] text-[#182033] border-b border-[#E3E8F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-2xl mb-16">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
            <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
              PROGRESSION & MILESTONES
            </span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#182033]">
            Academic & Professional Journey
          </h2>
          <p className="font-sans text-sm sm:text-base text-[#667085] mt-3">
            From entering university with academic distinction to cohort leadership, venture competition, and professional CA qualification.
          </p>
        </div>

        {/* Timeline Component Layout */}
        <div className="relative pl-6 sm:pl-8 border-l-2 border-[#3155D9]/30 space-y-10">
          {timelineData.map((item) => {
            const isSelected = selectedItem === item.id;
            const isExpanded = !!expandedItems[item.id];

            return (
              <div
                key={item.id}
                className="relative group cursor-pointer"
                onClick={() => setSelectedItem(item.id)}
              >
                {/* Timeline Dot Indicator */}
                <div
                  className={`absolute -left-[31px] sm:-left-[41px] top-2 w-4 h-4 rounded-full border-2 transition-all ${
                    isSelected
                      ? 'bg-[#3155D9] border-white ring-4 ring-[#3155D9]/20'
                      : 'bg-white border-[#3155D9] group-hover:bg-[#3155D9]'
                  }`}
                />

                {/* Card Container */}
                <div
                  className={`p-6 rounded-xl border bg-white transition-all shadow-xs ${
                    isSelected
                      ? 'border-[#3155D9] shadow-md shadow-[#3155D9]/10'
                      : 'border-[#E3E8F5] hover:border-[#3155D9]/50'
                  }`}
                >
                  {/* Top Bar with Year, Period, Category Badge */}
                  <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
                    <div className="flex items-center gap-3">
                      <span className=" text-xl sm:text-2xl font-bold text-[#182033]">
                        {item.year}
                      </span>
                      {item.period && (
                        <span className=" text-xs text-[#667085] px-2.5 py-0.5 rounded-md bg-[#FAFBFF] border border-[#E3E8F5]">
                          {item.period}
                        </span>
                      )}
                    </div>
                    <span className=" text-[11px] uppercase tracking-wider text-[#3155D9] px-2.5 py-0.5 rounded bg-[#E9EEFF] border border-[#3155D9]/20 font-semibold">
                      {item.category}
                    </span>
                  </div>

                  {/* Title & Subtitle */}
                  <h3 className="font-serif text-lg sm:text-xl font-bold text-[#182033]">
                    {item.title}
                  </h3>
                  <p className=" text-xs text-[#667085] mt-0.5">
                    {item.subtitle}
                  </p>

                  {/* Narrative paragraph */}
                  <p className="font-sans text-sm text-[#182033]/85 mt-3 leading-relaxed">
                    {item.description}
                  </p>

                  {/* Toggle Detailed Highlights */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleExpand(item.id);
                    }}
                    className="mt-4 inline-flex items-center gap-1.5  text-xs text-[#3155D9] hover:text-[#2444B8] font-medium transition-colors cursor-pointer"
                  >
                    <span>{isExpanded ? 'Hide Details' : 'Key Highlights & Competencies'}</span>
                    {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>

                  {/* Expandable Key Highlights and Skills Panel */}
                  {isExpanded && (
                    <div className="mt-4 pt-4 border-t border-[#E3E8F5] space-y-4">
                      {/* Highlights */}
                      <div>
                        <h4 className=" text-xs uppercase tracking-wider text-[#667085] mb-2 font-medium">
                          Key Milestone Highlights
                        </h4>
                        <ul className="space-y-1.5">
                          {item.highlights.map((highlight, hIdx) => (
                            <li
                              key={hIdx}
                              className="font-sans text-xs text-[#182033] flex items-start gap-2 leading-relaxed"
                            >
                              <span className="w-1.5 h-1.5 rounded-full bg-[#3155D9] shrink-0 mt-1.5" />
                              <span>{highlight}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Skills Gained */}
                      <div>
                        <h4 className=" text-xs uppercase tracking-wider text-[#667085] mb-2 font-medium">
                          Competencies Developed
                        </h4>
                        <div className="flex flex-wrap gap-1.5">
                          {item.skillsGained.map((skill, sIdx) => (
                            <span
                              key={sIdx}
                              className="px-2.5 py-0.5 rounded text-[11px]  bg-[#FAFBFF] border border-[#E3E8F5] text-[#182033]"
                            >
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
