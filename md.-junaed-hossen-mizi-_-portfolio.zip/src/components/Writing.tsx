import React, { useState } from 'react';
import { Clock, ArrowUpRight } from 'lucide-react';
import { labArticlesData } from '../data/portfolioData';
import { LabArticle } from '../types';
import { ArticleReaderModal } from './ArticleReaderModal';

export const Writing: React.FC = () => {
  const [selectedArticle, setSelectedArticle] = useState<LabArticle | null>(null);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Published':
        return 'bg-[#E9EEFF] text-[#3155D9] border-[#3155D9]/20';
      case 'Coming Soon':
        return 'bg-[#FAFBFF] text-[#667085] border-[#E3E8F5]';
      default:
        return 'bg-[#FAFBFF] text-[#667085] border-[#E3E8F5]';
    }
  };

  return (
    <section id="writing" className="py-20 md:py-28 bg-white text-[#182033] border-b border-[#E3E8F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-14">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
            <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
              KNOWLEDGE INITIATIVE & ESSAYS
            </span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#182033]">
            Junaed's Finance Lab
          </h2>
          <p className="font-sans text-sm sm:text-base text-[#667085] mt-3">
            Translating complex accounting standards, corporate balance sheets, and financial principles into clear, structured insights for students and emerging analysts.
          </p>
        </div>

        {/* Content Themes Pills */}
        <div className="mb-10 p-5 rounded-2xl bg-[#FAFBFF] border border-[#E3E8F5] flex flex-wrap items-center gap-2 text-xs">
          <span className=" text-[#3155D9] font-semibold mr-2">Focus Themes:</span>
          {[
            "Annual Report Breakdowns",
            "Financial Literacy",
            "Working Capital Dynamics",
            "Corporate Finance Theory",
            "Investment Mindset & Risk",
            "Bangladeshi Business Cases",
          ].map((theme, i) => (
            <span
              key={i}
              className="px-3 py-1 rounded-lg bg-white border border-[#E3E8F5] text-[#667085]  text-[11px]"
            >
              {theme}
            </span>
          ))}
        </div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {labArticlesData.map((article) => (
            <div
              key={article.id}
              onClick={() => setSelectedArticle(article)}
              className="p-6 rounded-2xl bg-[#FAFBFF] border border-[#E3E8F5] hover:border-[#3155D9] transition-all shadow-xs hover:shadow-lg hover:shadow-[#3155D9]/5 flex flex-col justify-between cursor-pointer group"
            >
              <div>
                {/* Header with status and read time */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span
                    className={`px-2.5 py-0.5 rounded-md text-[10px]  uppercase tracking-wider border font-medium ${getStatusBadge(
                      article.status
                    )}`}
                  >
                    {article.status}
                  </span>
                  <span className="text-[11px]  text-[#667085] flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {article.readTime}
                  </span>
                </div>

                {/* Topic tag */}
                <span className="block text-[11px]  text-[#3155D9] font-semibold mb-1">
                  {article.topic}
                </span>

                {/* Title */}
                <h3 className="font-serif text-lg font-bold text-[#182033] group-hover:text-[#3155D9] transition-colors leading-snug">
                  {article.title}
                </h3>

                {/* Summary */}
                <p className="font-sans text-xs text-[#667085] mt-2.5 leading-relaxed line-clamp-3">
                  {article.summary}
                </p>
              </div>

              {/* Bottom Action */}
              <div className="mt-6 pt-3.5 border-t border-[#E3E8F5] flex items-center justify-between text-xs  text-[#182033] group-hover:text-[#3155D9] transition-colors">
                <span>
                  {article.status === 'Published' ? 'Read Analysis' : 'Preview Outline'}
                </span>
                <ArrowUpRight className="w-3.5 h-3.5 text-[#3155D9] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </div>
            </div>
          ))}
        </div>

        {/* Modal Reader */}
        <ArticleReaderModal
          article={selectedArticle}
          onClose={() => setSelectedArticle(null)}
        />

      </div>
    </section>
  );
};
