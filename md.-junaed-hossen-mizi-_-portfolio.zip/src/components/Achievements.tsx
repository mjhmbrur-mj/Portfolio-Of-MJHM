import React, { useState } from 'react';
import { ArrowUpRight, ShieldCheck, Eye, FileText, CheckCircle2 } from 'lucide-react';
import { achievementDocumentsData } from '../data/achievementDocumentsData';
import { AchievementLightboxModal } from './academics/AchievementLightboxModal';
import { AchievementDocumentItem } from '../types';

interface AchievementsProps {
  onNavigateToAcademics?: () => void;
}

export const Achievements: React.FC<AchievementsProps> = ({ onNavigateToAcademics }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedAchievement, setSelectedAchievement] = useState<AchievementDocumentItem | null>(null);

  const categories = [
    { id: 'all', label: 'All Documents & Honors' },
    { id: 'Academic', label: 'Academic Standing' },
    { id: 'Scholarship', label: 'Scholarships' },
    { id: 'University', label: 'University' },
    { id: 'Competition', label: 'Competitions' },
    { id: 'Global Summit', label: 'Global Summits' },
    { id: 'Training', label: 'Professional Training' },
  ];

  const filteredAchievements = activeCategory === 'all'
    ? achievementDocumentsData
    : achievementDocumentsData.filter((a) => a.category === activeCategory);

  const activeIndex = selectedAchievement
    ? filteredAchievements.findIndex((a) => a.id === selectedAchievement.id)
    : -1;

  const handleNext = () => {
    if (activeIndex >= 0 && activeIndex < filteredAchievements.length - 1) {
      setSelectedAchievement(filteredAchievements[activeIndex + 1]);
    }
  };

  const handlePrev = () => {
    if (activeIndex > 0) {
      setSelectedAchievement(filteredAchievements[activeIndex - 1]);
    }
  };

  return (
    <section id="achievements" className="py-20 md:py-28 bg-white text-[#182033] border-b border-[#E3E8F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-baseline justify-between gap-6 mb-12">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
              <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
                HONORS & VERIFIED DOCUMENTS
              </span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#182033]">
              Academic Achievements
            </h2>
            <p className="font-sans text-sm sm:text-base text-[#667085] mt-3 leading-relaxed">
              Official academic marksheet scans, institutional honors, competition certificates, and international summits with authentic documentation.
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap gap-1.5">
            {categories.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setActiveCategory(cat.id)}
                className={`px-3 py-1.5 rounded-lg text-xs  transition-all duration-150 cursor-pointer ${
                  activeCategory === cat.id
                    ? 'bg-[#3155D9] text-white font-medium shadow-xs'
                    : 'bg-[#FAFBFF] text-[#667085] hover:text-[#182033] border border-[#E3E8F5]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Prominent Achievement Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAchievements.map((item) => (
            <div
              key={item.id}
              onClick={() => setSelectedAchievement(item)}
              className="group cursor-pointer rounded-2xl bg-white border border-[#E3E8F5] hover:border-[#3155D9] overflow-hidden transition-all duration-200 shadow-xs hover:shadow-lg hover:shadow-[#3155D9]/10 flex flex-col justify-between"
            >
              <div>
                {/* Real Image Container */}
                <div className="relative aspect-[16/10] bg-[#FAFBFF] border-b border-[#E3E8F5] overflow-hidden flex items-center justify-center">
                  <img
                    src={item.image}
                    alt={item.imageAlt}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-top transition-transform duration-300 group-hover:scale-105"
                    onError={(e) => {
                      // Fallback placeholder if image load encounters an issue
                      const target = e.currentTarget;
                      target.style.display = 'none';
                      const parent = target.parentElement;
                      if (parent) {
                        const fallback = parent.querySelector('.img-fallback');
                        if (fallback) (fallback as HTMLElement).style.display = 'flex';
                      }
                    }}
                  />

                  {/* Fallback view */}
                  <div className="img-fallback hidden absolute inset-0 bg-[#FAFBFF] flex-col items-center justify-center p-4 text-center">
                    <FileText className="w-8 h-8 text-[#3155D9] mb-2" />
                    <span className=" text-xs text-[#182033] font-semibold">{item.documentType || 'Official Document'}</span>
                    <span className=" text-[10px] text-[#667085]">{item.issuer || 'Institutional Record'}</span>
                  </div>

                  {/* Hover Overlay with Preview prompt */}
                  <div className="absolute inset-0 bg-[#182033]/40 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center backdrop-blur-xs">
                    <span className="px-3.5 py-1.5 rounded-lg bg-white text-[#182033]  text-xs font-semibold shadow-md flex items-center gap-1.5">
                      <Eye className="w-3.5 h-3.5 text-[#3155D9]" />
                      <span>Inspect Document</span>
                    </span>
                  </div>

                  {/* Top Badges */}
                  <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 z-10">
                    <span className=" text-[10px] uppercase font-semibold px-2 py-0.5 rounded bg-white/95 text-[#3155D9] border border-[#E3E8F5] shadow-xs">
                      {item.documentType || item.category}
                    </span>
                    {item.distinction && (
                      <span className=" text-[10px] font-medium px-2 py-0.5 rounded bg-[#3155D9] text-white shadow-xs">
                        {item.distinction}
                      </span>
                    )}
                  </div>

                  {item.privacyProtected && (
                    <div className="absolute top-2.5 right-2.5 z-10">
                      <span className="inline-flex items-center gap-1  text-[10px] px-2 py-0.5 rounded bg-white/95 text-[#667085] border border-[#E3E8F5] shadow-xs">
                        <ShieldCheck className="w-3 h-3 text-[#3155D9]" />
                        <span>Redacted</span>
                      </span>
                    </div>
                  )}
                </div>

                {/* Card Content */}
                <div className="p-5">
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className=" text-xs text-[#3155D9] font-medium">
                      {item.issuer || item.category}
                    </span>
                    {item.year && (
                      <span className=" text-xs text-[#667085]">
                        {item.year}
                      </span>
                    )}
                  </div>

                  <h3 className="font-serif text-base sm:text-lg font-bold text-[#182033] group-hover:text-[#3155D9] transition-colors leading-snug">
                    {item.title}
                  </h3>

                  <p className="font-sans text-xs text-[#667085] mt-2 line-clamp-3 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>

              {/* Card Footer */}
              <div className="px-5 pb-4 pt-3 border-t border-[#E3E8F5] flex items-center justify-between text-xs  text-[#3155D9] font-medium">
                <span>View Full Scan</span>
                <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </div>
            </div>
          ))}
        </div>

        {/* Board Scholarship & Archive CTA (NO BLACK BACKGROUND) */}
        <div className="mt-12 p-7 rounded-2xl bg-[#FAFBFF] border-2 border-[#3155D9]/30 text-[#182033] flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xs">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
              <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
                COMPLETE ACADEMIC VAULT
              </span>
            </div>
            <h4 className="font-serif text-xl font-bold text-[#182033]">
              Verified Academic Dossier & Semester Records
            </h4>
            <p className="font-sans text-xs sm:text-sm text-[#667085] mt-1">
              Explore semester-by-semester GPA breakdowns, course transcripts, verified certificates, and regional merit records.
            </p>
          </div>

          {onNavigateToAcademics && (
            <button
              type="button"
              onClick={onNavigateToAcademics}
              className="px-5 py-2.5 rounded-lg bg-[#3155D9] hover:bg-[#2444B8] text-white text-xs font-sans font-medium inline-flex items-center gap-2 transition-colors cursor-pointer shrink-0 shadow-sm shadow-[#3155D9]/20"
            >
              <span>Explore Document Archive</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

      </div>

      {/* Lightbox Modal for Full Document Inspection */}
      <AchievementLightboxModal
        isOpen={!!selectedAchievement}
        achievement={selectedAchievement}
        onClose={() => setSelectedAchievement(null)}
        onNext={handleNext}
        onPrev={handlePrev}
        hasNext={activeIndex < filteredAchievements.length - 1}
        hasPrev={activeIndex > 0}
      />
    </section>
  );
};
