import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowUpRight, ArrowLeft } from 'lucide-react';
import { profileData } from '../data/portfolioData';

interface NavbarProps {
  activeSection: string;
  currentPage: 'home' | 'academics';
  onNavigate: (page: 'home' | 'academics') => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeSection, currentPage, onNavigate }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'About', href: '#about' },
    { label: 'Journey', href: '#journey' },
    { label: 'Academic', href: '#education' },
    { label: 'Projects', href: '#projects' },
    { label: 'Research', href: '#research' },
    { label: 'Writing', href: '#writing' },
    { label: 'Contact', href: '#contact' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    if (currentPage !== 'home') {
      onNavigate('home');
      setTimeout(() => {
        const target = document.querySelector(href);
        if (target) target.scrollIntoView({ behavior: 'smooth' });
      }, 100);
      return;
    }
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header
        id="main-navigation-header"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-200 ${
          isScrolled
            ? 'bg-white/95 backdrop-blur-md border-b border-[#E3E8F5] py-3.5 shadow-sm'
            : 'bg-white/80 backdrop-blur-xs py-5 border-b border-[#E3E8F5]/60'
        }`}
      >
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          
          {/* Logo / Name on the left: Junaed Hossen */}
          <a
            href="#home"
            onClick={(e) => {
              e.preventDefault();
              if (currentPage !== 'home') {
                onNavigate('home');
              } else {
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }
            }}
            id="nav-logo-name"
            className="flex items-center gap-2 group text-left cursor-pointer"
          >
            <span className="font-serif text-lg sm:text-xl font-bold tracking-tight text-[#182033] group-hover:text-[#3155D9] transition-colors">
              Junaed Hossen
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#3155D9] inline-block" />
            <span className="hidden md:inline-block  text-[11px] text-[#667085] tracking-wider ml-1">
              FINANCE · BRUR
            </span>
          </a>

          {/* Navigation on the right */}
          {currentPage === 'home' ? (
            <nav className="hidden lg:flex items-center gap-6 text-sm font-sans font-medium text-[#182033]">
              {navLinks.map((link) => {
                const targetId = link.href.replace('#', '');
                const isActive = activeSection === targetId;
                return (
                  <a
                    key={link.href}
                    href={link.href}
                    onClick={(e) => handleNavClick(e, link.href)}
                    className={`transition-colors py-1 relative ${
                      isActive
                        ? 'text-[#3155D9] font-semibold'
                        : 'text-[#667085] hover:text-[#182033]'
                    }`}
                  >
                    <span>{link.label}</span>
                    {isActive && (
                      <span className="absolute -bottom-1 left-0 right-0 h-[2px] bg-[#3155D9] rounded-full" />
                    )}
                  </a>
                );
              })}

              {/* Dedicated Academic Achievements Page Link */}
              <button
                type="button"
                onClick={() => onNavigate('academics')}
                className=" text-xs text-[#3155D9] bg-[#E9EEFF] hover:text-white hover:bg-[#3155D9] px-3 py-1.5 rounded-md border border-[#3155D9]/30 transition-colors cursor-pointer"
              >
                Archive ↗
              </button>
            </nav>
          ) : (
            <nav className="hidden sm:flex items-center gap-4">
              <button
                type="button"
                onClick={() => onNavigate('home')}
                className="inline-flex items-center gap-2  text-xs text-[#667085] hover:text-[#182033] transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Return to Portfolio</span>
              </button>
              <span className=" text-xs text-[#3155D9] bg-[#E9EEFF] px-2.5 py-0.5 rounded border border-[#3155D9]/20 font-medium">
                Academic Achievements
              </span>
            </nav>
          )}

          {/* Right Mobile Toggle */}
          <div className="flex items-center gap-3 lg:hidden">
            <button
              type="button"
              onClick={() => onNavigate(currentPage === 'academics' ? 'home' : 'academics')}
              className=" text-xs text-[#3155D9] bg-[#E9EEFF] border border-[#3155D9]/30 px-2.5 py-1 rounded-md"
            >
              {currentPage === 'academics' ? 'Home' : 'Archive'}
            </button>

            <button
              type="button"
              id="mobile-menu-toggle-button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1.5 text-[#182033] hover:text-[#3155D9] transition-colors"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>
      </header>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="fixed inset-0 bg-[#182033]/40 backdrop-blur-xs"
            onClick={() => setMobileMenuOpen(false)}
          />

          <div className="fixed top-0 right-0 bottom-0 w-72 bg-white border-l border-[#E3E8F5] p-6 flex flex-col justify-between overflow-y-auto shadow-2xl">
            <div>
              <div className="flex items-center justify-between pb-5 border-b border-[#E3E8F5]">
                <div>
                  <span className="font-serif text-lg font-bold text-[#182033]">
                    Junaed Hossen
                  </span>
                  <span className="block  text-[11px] text-[#667085] mt-0.5">
                    Finance & Banking · BRUR
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-[#667085] hover:text-[#182033]"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Dedicated Academic Page button */}
              <div className="my-4">
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onNavigate(currentPage === 'academics' ? 'home' : 'academics');
                  }}
                  className="w-full text-left p-3 rounded-lg bg-[#E9EEFF] border border-[#3155D9]/30 text-xs  text-[#182033] hover:border-[#3155D9] transition-colors"
                >
                  <span className="text-[#3155D9] block text-[10px] font-semibold">DEDICATED DOSSIER</span>
                  {currentPage === 'academics' ? '← Back to Main Portfolio' : 'Academic Achievements Archive →'}
                </button>
              </div>

              {/* Nav links */}
              <div className="space-y-2 py-2 font-sans text-sm">
                {navLinks.map((link) => (
                  <a
                    key={link.href}
                    href={link.href}
                    onClick={(e) => handleNavClick(e, link.href)}
                    className="block py-2 text-[#667085] hover:text-[#3155D9] transition-colors font-medium"
                  >
                    {link.label}
                  </a>
                ))}
              </div>
            </div>

            <div className="pt-6 border-t border-[#E3E8F5]">
              <span className="block  text-[11px] text-[#667085] mb-1">
                Direct Contact
              </span>
              <a
                href={`mailto:${profileData.contact.email}`}
                className=" text-xs text-[#3155D9] hover:underline transition-colors break-all"
              >
                {profileData.contact.email}
              </a>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
