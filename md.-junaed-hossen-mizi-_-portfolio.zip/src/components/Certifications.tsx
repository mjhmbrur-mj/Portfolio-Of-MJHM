import React from 'react';
import { certificationsData } from '../data/portfolioData';

export const Certifications: React.FC = () => {
  return (
    <section id="certifications" className="py-20 md:py-24 bg-[#FAFBFF] text-[#182033] border-b border-[#E3E8F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-12">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
            <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
              CREDENTIAL TRACK
            </span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#182033]">
            Professional Training & Credentials
          </h2>
          <p className="font-sans text-sm sm:text-base text-[#667085] mt-3 leading-relaxed">
            Cultivating credentials through statutory accounting bodies, multilateral developmental assemblies, national stock exchanges, and research symposiums.
          </p>
        </div>

        {/* Learning Ecosystem Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {certificationsData.map((cert) => (
            <div
              key={cert.id}
              className="p-6 rounded-2xl bg-white border border-[#E3E8F5] hover:border-[#3155D9] transition-all shadow-xs hover:shadow-lg hover:shadow-[#3155D9]/5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className=" text-xs text-[#3155D9] font-semibold">
                    {cert.issuer}
                  </span>
                  <span className="text-[10px]  px-2 py-0.5 rounded-md bg-[#E9EEFF] text-[#3155D9] border border-[#3155D9]/20 font-medium">
                    {cert.status}
                  </span>
                </div>

                <h3 className="font-serif text-base font-bold text-[#182033]">
                  {cert.title}
                </h3>

                <p className="font-sans text-xs text-[#667085] mt-2.5 leading-relaxed">
                  {cert.description}
                </p>
              </div>

              <div className="mt-5 pt-4 border-t border-[#E3E8F5]">
                <div className="flex flex-wrap gap-1.5 mb-3">
                  {cert.tags.map((tag, i) => (
                    <span
                      key={i}
                      className="text-[10px]  px-2 py-0.5 rounded-md bg-[#FAFBFF] text-[#667085] border border-[#E3E8F5]"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                <div className="flex items-center justify-between text-[11px]  text-[#667085]">
                  <span>Year {cert.year}</span>
                  <span className="text-[#3155D9] font-medium">Documented</span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
