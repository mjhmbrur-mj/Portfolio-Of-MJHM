import React, { useState } from 'react';
import { ArrowUpRight, PieChart } from 'lucide-react';
import { projectsData } from '../data/portfolioData';
import { ProjectItem } from '../types';
import { ProjectDetailModal } from './ProjectDetailModal';

export const Projects: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);

  return (
    <section id="projects" className="py-20 md:py-28 bg-[#FAFBFF] text-[#182033] border-b border-[#E3E8F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-14">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
            <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
              APPLIED VENTURES & INITIATIVES
            </span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#182033]">
            Projects & Initiatives
          </h2>
          <p className="font-sans text-sm sm:text-base text-[#667085] mt-3">
            Translating financial analysis, unit economics, and educational insight into startup proposals, venture competitions, and academic resources.
          </p>
        </div>

        {/* Projects Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
          {projectsData.map((project) => {
            const isHaatkotha = project.id === 'haatkotha';
            const isFinanceLab = project.id === 'finance-lab';
            const isMockPlatform = project.id === 'ca-mock-platform';

            return (
              <div
                key={project.id}
                className="p-6 rounded-2xl bg-white border border-[#E3E8F5] hover:border-[#3155D9] flex flex-col justify-between transition-all duration-150 shadow-xs hover:shadow-lg hover:shadow-[#3155D9]/5"
              >
                <div>
                  {/* Status & Role Badges */}
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                    <span className=" text-[11px] text-[#3155D9] uppercase tracking-wider font-semibold bg-[#E9EEFF] px-2.5 py-0.5 rounded-md border border-[#3155D9]/20">
                      {project.status}
                    </span>
                    <span className=" text-xs text-[#667085]">
                      {project.role}
                    </span>
                  </div>

                  {/* Achievement Badge if applicable */}
                  {project.achievement && (
                    <div className="mb-3 inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-[#E9EEFF] border border-[#3155D9]/30  text-xs text-[#3155D9] font-medium">
                      <span>{project.achievement}</span>
                    </div>
                  )}

                  {/* Title & Tagline */}
                  <h3 className="font-serif text-xl font-bold text-[#182033] leading-tight">
                    {project.title}
                  </h3>
                  <p className="font-sans text-xs text-[#667085] mt-1 leading-snug">
                    {project.tagline}
                  </p>

                  {/* Description */}
                  <p className="font-sans text-xs sm:text-sm text-[#182033]/80 mt-3 leading-relaxed">
                    {project.description}
                  </p>

                  {/* Project-specific preview */}
                  {isHaatkotha && project.budgetConcept && (
                    <div className="mt-4 p-3.5 rounded-xl bg-[#FAFBFF] border border-[#E3E8F5]">
                      <div className="flex items-center justify-between text-xs  text-[#667085] mb-2">
                        <span className="flex items-center gap-1 text-[#3155D9] font-medium">
                          <PieChart className="w-3.5 h-3.5" />
                          <span>Budget: {project.budgetConcept.total}</span>
                        </span>
                        <span className="text-[10px]">5 Allocations</span>
                      </div>
                      
                      <div className="w-full h-2.5 rounded-full overflow-hidden flex bg-[#E3E8F5]">
                        {project.budgetConcept.breakdown.map((item, i) => (
                          <div
                            key={i}
                            style={{ width: `${item.percentage}%`, backgroundColor: item.color }}
                            title={`${item.category}: ${item.percentage}%`}
                          />
                        ))}
                      </div>

                      <div className="grid grid-cols-2 gap-1.5 mt-2.5 text-[10px]  text-[#667085]">
                        <div>• Tech: 30%</div>
                        <div>• Mktg: 25%</div>
                        <div>• Artisans: 20%</div>
                        <div>• Operations: 15%</div>
                      </div>
                    </div>
                  )}

                  {isFinanceLab && (
                    <div className="mt-4 p-3.5 rounded-xl bg-[#FAFBFF] border border-[#E3E8F5] space-y-1.5 text-xs font-sans text-[#667085]">
                      <div className=" text-[11px] text-[#3155D9] font-semibold mb-1">
                        Content Pillars
                      </div>
                      <div className="text-[#182033]">・ Annual Report Breakdown Guides</div>
                      <div className="text-[#182033]">・ Working Capital & Liquidity Models</div>
                      <div className="text-[#182033]">・ Corporate Valuation Fundamentals</div>
                    </div>
                  )}

                  {isMockPlatform && (
                    <div className="mt-4 p-3.5 rounded-xl bg-[#FAFBFF] border border-[#E3E8F5]">
                      <div className=" text-[11px] text-[#3155D9] font-semibold mb-2">
                        Platform Structure
                      </div>
                      <div className="grid grid-cols-2 gap-1.5 text-[10px]  text-[#182033]">
                        <span className="p-1.5 rounded bg-white border border-[#E3E8F5]">MCQ Diagnostic</span>
                        <span className="p-1.5 rounded bg-white border border-[#E3E8F5]">Past Paper Bank</span>
                        <span className="p-1.5 rounded bg-white border border-[#E3E8F5]">Accuracy Tracker</span>
                        <span className="p-1.5 rounded bg-white border border-[#E3E8F5]">Timed Exams</span>
                      </div>
                    </div>
                  )}

                  {/* Tags */}
                  <div className="mt-4 flex flex-wrap gap-1">
                    {project.tags.map((tag, tIdx) => (
                      <span
                        key={tIdx}
                        className="text-[10px]  px-2 py-0.5 rounded bg-[#FAFBFF] text-[#667085] border border-[#E3E8F5]"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Bottom CTA Button */}
                <div className="mt-6 pt-3.5 border-t border-[#E3E8F5]">
                  <button
                    type="button"
                    onClick={() => setSelectedProject(project)}
                    className="w-full py-2.5 px-3 rounded-lg text-xs  bg-[#FAFBFF] hover:bg-white text-[#182033] hover:text-[#3155D9] border border-[#E3E8F5] hover:border-[#3155D9] transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <span>{isHaatkotha ? 'Inspect Budget Model' : 'View Specifications'}</span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-[#3155D9]" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Interactive Modal */}
        <ProjectDetailModal
          project={selectedProject}
          onClose={() => setSelectedProject(null)}
        />

      </div>
    </section>
  );
};
