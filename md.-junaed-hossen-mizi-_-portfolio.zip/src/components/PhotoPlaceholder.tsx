import React, { useState } from 'react';
import { Camera, ShieldCheck, Sparkles, TrendingUp } from 'lucide-react';

interface PhotoPlaceholderProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const PhotoPlaceholder: React.FC<PhotoPlaceholderProps> = ({
  className = '',
  size = 'lg',
}) => {
  const [imgError, setImgError] = useState(false);

  return (
    <div className={`relative group ${className}`}>
      {/* Outer ambient glow */}
      <div className="absolute -inset-1 bg-[#3155D9]/15 rounded-2xl blur-xl opacity-70 group-hover:opacity-100 transition duration-700 pointer-events-none" />

      {/* Frame Container */}
      <div className="relative rounded-2xl overflow-hidden border border-[#E3E8F5] bg-white shadow-xl">
        {/* Subtle grid pattern overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#3155D908_1px,transparent_1px),linear-gradient(to_bottom,#3155D908_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none" />

        {/* Top corner accents */}
        <div className="absolute top-2 left-2 w-3 h-3 border-t-2 border-l-2 border-[#3155D9] z-10" />
        <div className="absolute top-2 right-2 w-3 h-3 border-t-2 border-r-2 border-[#3155D9] z-10" />
        <div className="absolute bottom-2 left-2 w-3 h-3 border-b-2 border-l-2 border-[#3155D9] z-10" />
        <div className="absolute bottom-2 right-2 w-3 h-3 border-b-2 border-r-2 border-[#3155D9] z-10" />

        {!imgError ? (
          <img
            src="/assets/profile.jpg"
            alt="Md. Junaed Hossen Mizi - Finance & Banking Student"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover object-center aspect-[4/5] filter contrast-[1.03] transition duration-500 group-hover:scale-102"
          />
        ) : (
          /* High-craft editorial placeholder when profile.jpg is not yet uploaded */
          <div className="aspect-[4/5] w-full flex flex-col items-center justify-between p-6 bg-[#FAFBFF] text-center relative">
            {/* Upper status badge */}
            <div className="w-full flex items-center justify-between z-10">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-[#E9EEFF] text-[#3155D9] border border-[#3155D9]/25">
                <span className="w-1.5 h-1.5 rounded-full bg-[#3155D9] animate-pulse" />
                ICAB CA Student
              </span>
              <span className="text-[11px]  text-[#667085]">BRUR '27</span>
            </div>

            {/* Central Monogram & Heraldic Seal */}
            <div className="my-auto flex flex-col items-center justify-center relative">
              {/* Concentric rings */}
              <div className="w-36 h-36 rounded-full border border-[#3155D9]/25 flex items-center justify-center bg-white p-2 shadow-sm">
                <div className="w-28 h-28 rounded-full border border-[#E3E8F5] flex items-center justify-center bg-[#FAFBFF] shadow-xs">
                  <div className="text-center">
                    <span className="block text-3xl font-extrabold tracking-widest text-[#182033] font-serif">
                      JHM
                    </span>
                    <span className="block text-[9px]  tracking-wider text-[#3155D9] font-bold mt-0.5">
                      FINANCE & BANKING
                    </span>
                  </div>
                </div>
              </div>

              {/* Decorative financial curve beneath seal */}
              <div className="mt-4 flex items-center gap-2 text-xs text-[#667085] ">
                <TrendingUp className="w-3.5 h-3.5 text-[#3155D9]" />
                <span>Turning numbers into decisions</span>
              </div>
            </div>

            {/* Bottom identity tag and photo instruction */}
            <div className="w-full pt-4 border-t border-[#E3E8F5] z-10">
              <p className="text-sm font-serif font-bold text-[#182033]">Md. Junaed Hossen Mizi</p>
              <p className="text-xs text-[#667085] mt-0.5">Begum Rokeya University, Rangpur</p>
              <div className="mt-2.5 inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-white border border-[#E3E8F5] text-[11px] text-[#667085] hover:text-[#3155D9] shadow-2xs transition-colors">
                <Camera className="w-3 h-3 text-[#3155D9]" />
                <span>Replace with /assets/profile.jpg</span>
              </div>
            </div>
          </div>
        )}

        {/* Floating live tag over photo */}
        <div className="absolute bottom-3 right-3 z-20 pointer-events-none">
          <div className="px-3 py-1 rounded-lg bg-white/95 backdrop-blur-md border border-[#E3E8F5] shadow-md flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5 text-[#3155D9]" />
            <span className="text-[11px] font-medium text-[#182033]">BBA 15th Batch</span>
          </div>
        </div>
      </div>
    </div>
  );
};
