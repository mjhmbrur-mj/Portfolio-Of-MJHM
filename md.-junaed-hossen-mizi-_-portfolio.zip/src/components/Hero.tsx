import React from 'react';
import { ArrowDown, ArrowUpRight } from 'lucide-react';
import { profileData } from '../data/portfolioData';
import { PhotoPlaceholder } from './PhotoPlaceholder';

export const Hero: React.FC = () => {
  const scrollTo = (href: string) => {
    const el = document.querySelector(href);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      className="relative min-h-[90vh] pt-28 pb-16 md:pt-36 md:pb-24 flex items-center bg-white text-[#182033] overflow-hidden border-b border-[#E3E8F5]"
    >
      {/* Subtle fine architectural grid line background with restraint */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.03]">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#3155D9_1px,transparent_1px),linear-gradient(to_bottom,#3155D9_1px,transparent_1px)] bg-[size:40px_40px]" />
      </div>

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 w-full z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Editorial Headline & Narrative */}
          <div className="lg:col-span-7 flex flex-col text-left">
            
            {/* Small Technical Label in Aptos */}
            <div className="flex items-center gap-2 mb-4">
              <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
              <span className="text-xs text-[#3155D9] tracking-wider uppercase font-semibold">
                FINANCE & BANKING · CA ASPIRANT
              </span>
            </div>

            {/* Candidate Name in subtle uppercase */}
            <span className="text-xs text-[#667085] uppercase tracking-wider mb-3 block">
              Md. Junaed Hossen Mizi
            </span>

            {/* Major Headline in DM Serif Display with Cobalt Accent */}
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-[#182033] leading-[1.12] tracking-tight mb-6">
              Learning finance today.<br />
              <span className="text-[#3155D9] italic font-normal">Building impact for tomorrow.</span>
            </h1>

            {/* Supporting Text in Aptos */}
            <p className="text-base sm:text-lg text-[#667085] leading-relaxed max-w-xl mb-7 font-normal">
              Finance & Banking undergraduate at Begum Rokeya University, Rangpur, actively building a rigorous foundation across corporate finance, statutory accounting, empirical research, and institutional leadership.
            </p>

            {/* Editorial Positioning Note with signature Cobalt line */}
            <div className="pl-4 border-l-2 border-[#3155D9] bg-[#FAFBFF] py-3 pr-4 rounded-r-lg mb-8 max-w-lg border border-[#E3E8F5] border-l-2">
              <p className="text-[11px] text-[#3155D9] uppercase tracking-wider font-medium mb-1">
                Student Perspective
              </p>
              <p className="text-sm text-[#182033] italic">
                "{profileData.positioningStatement}"
              </p>
            </div>

            {/* Action Buttons: Cobalt + White */}
            <div className="flex flex-wrap items-center gap-3.5 mb-10">
              <button
                type="button"
                onClick={() => scrollTo('#journey')}
                id="hero-cta-journey"
                className="px-5 py-2.5 rounded-lg text-sm font-medium bg-[#3155D9] hover:bg-[#2444B8] text-white transition-colors duration-150 flex items-center gap-2 cursor-pointer shadow-sm shadow-[#3155D9]/20"
              >
                <span>Explore Journey</span>
                <ArrowDown className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => scrollTo('#projects')}
                id="hero-cta-projects"
                className="px-5 py-2.5 rounded-lg text-sm font-medium bg-white hover:bg-[#E9EEFF] text-[#3155D9] border border-[#3155D9]/30 transition-colors duration-150 flex items-center gap-2 cursor-pointer"
              >
                <span>Selected Work</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-[#3155D9]" />
              </button>

              <button
                type="button"
                onClick={() => scrollTo('#contact')}
                id="hero-cta-connect"
                className="px-4 py-2.5 text-sm font-medium text-[#667085] hover:text-[#3155D9] transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <span>Contact</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Subtle Metadata Strip in Aptos */}
            <div className="grid grid-cols-3 gap-6 pt-6 border-t border-[#E3E8F5] max-w-md">
              <div>
                <span className="block text-xl font-semibold text-[#182033]">3.67</span>
                <span className="block text-[11px] text-[#667085] mt-0.5">CURRENT CGPA</span>
              </div>
              <div>
                <span className="block text-xl font-semibold text-[#3155D9]">ICAB</span>
                <span className="block text-[11px] text-[#667085] mt-0.5">CERTIFICATE LEVEL</span>
              </div>
              <div>
                <span className="block text-xl font-semibold text-[#182033]">2022—2027</span>
                <span className="block text-[11px] text-[#667085] mt-0.5">UNDERGRADUATE</span>
              </div>
            </div>

          </div>

          {/* Right Column: Clean Portrait Framing */}
          <div className="lg:col-span-5 flex flex-col items-center lg:items-end justify-center">
            <div className="w-full max-w-sm">
              <div className="p-2.5 rounded-2xl bg-[#FAFBFF] border border-[#E3E8F5] shadow-lg shadow-[#3155D9]/5">
                <PhotoPlaceholder className="w-full" size="lg" />
              </div>
              
              {/* Editorial Caption Underneath */}
              <div className="mt-3 flex items-center justify-between px-1 text-[11px]  text-[#667085]">
                <span>BRUR · RANGPUR</span>
                <span className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#3155D9]" />
                  <span className="text-[#3155D9] font-medium">DEPT. OF FINANCE & BANKING</span>
                </span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
