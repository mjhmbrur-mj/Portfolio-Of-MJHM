import React from 'react';
import { BookOpen, GraduationCap, Award, CheckCircle2, ChevronRight, BarChart2, ShieldCheck } from 'lucide-react';
import { academicProfile } from '../../data/academicAchievementsData';

export const AcademicPerformanceCard: React.FC = () => {
  return (
    <section id="performance" className="py-20 md:py-24 bg-white border-b border-[#E3E8F5] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E9EEFF] border border-[#3155D9]/20 text-xs  text-[#3155D9] uppercase tracking-wider mb-3 font-semibold">
            <BarChart2 className="w-3.5 h-3.5" />
            <span>Cumulative Standing</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold tracking-tight text-[#182033]">
            Academic Performance.
          </h2>
          <p className="text-base sm:text-lg text-[#667085] mt-4 leading-relaxed font-sans">
            Cultivating rigorous discipline across corporate finance, auditing standards, banking jurisprudence, and monetary economics at Begum Rokeya University, Rangpur.
          </p>
        </div>

        {/* Sophisticated Academic Performance Card */}
        <div className="p-8 sm:p-10 rounded-3xl bg-[#FAFBFF] border border-[#E3E8F5] shadow-sm relative overflow-hidden">
          
          {/* Card Header & Institutional Identity */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-8 border-b border-[#E3E8F5]">
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-2">
                <span className="px-3 py-1 rounded-full text-xs  font-bold bg-[#E9EEFF] text-[#3155D9] border border-[#3155D9]/20">
                  Undergraduate Major Program
                </span>
                <span className="px-3 py-1 rounded-full text-xs  text-[#667085] bg-white border border-[#E3E8F5] font-medium">
                  Session: {academicProfile.session}
                </span>
                <span className="px-3 py-1 rounded-full text-xs  text-[#3155D9] bg-white border border-[#3155D9]/25 font-bold">
                  Class Representative (15th Batch)
                </span>
              </div>
              
              <h3 className="text-2xl sm:text-3xl font-serif font-bold text-[#182033] tracking-tight">
                {academicProfile.degreeTitle}
              </h3>
              <p className="text-sm sm:text-base text-[#667085] font-medium mt-1">
                {academicProfile.department} • {academicProfile.university}
              </p>
            </div>

            {/* Current Metrics Box */}
            <div className="flex items-center gap-4 sm:gap-6 bg-white p-5 rounded-2xl border border-[#E3E8F5] shrink-0 shadow-2xs">
              <div className="text-center px-3 sm:px-4 border-r border-[#E3E8F5]">
                <span className="block text-[10px]  uppercase tracking-wider text-[#667085] mb-1 font-semibold">
                  Cumulative CGPA
                </span>
                <div className="text-3xl sm:text-4xl font-black  text-[#3155D9]">
                  {academicProfile.currentCgpa}
                </div>
                <span className="text-[10px]  text-[#667085]">out of 4.00 scale</span>
              </div>

              <div className="text-center px-3 sm:px-4">
                <span className="block text-[10px]  uppercase tracking-wider text-[#667085] mb-1 font-semibold">
                  Latest SGPA
                </span>
                <div className="text-3xl sm:text-4xl font-black  text-[#182033]">
                  {academicProfile.latestSgpa}
                </div>
                <span className="text-[10px]  text-[#667085]">recent semester</span>
              </div>
            </div>
          </div>

          {/* Academic Journey Visual Flow Track (Undergraduate Timeline) */}
          <div className="mt-8 pt-2">
            <h4 className="text-xs  uppercase tracking-wider text-[#667085] font-bold mb-5 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-[#3155D9]" />
              <span>Undergraduate Progression Map (2022–2027)</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              
              {/* Year 1 */}
              <div className="p-4 rounded-xl bg-white border border-[#E3E8F5] shadow-2xs">
                <div className="flex items-center justify-between text-xs  text-[#667085] mb-2">
                  <span>Year 01 (2023)</span>
                  <span className="text-[#3155D9] font-bold">Completed</span>
                </div>
                <h5 className="text-sm font-bold text-[#182033]">Business & Quantitative Core</h5>
                <p className="text-xs text-[#667085] mt-1.5 leading-relaxed">
                  Accounting principles, microeconomics, statistics, business math, and introductory financial management.
                </p>
              </div>

              {/* Year 2 */}
              <div className="p-4 rounded-xl bg-white border border-[#E3E8F5] shadow-2xs">
                <div className="flex items-center justify-between text-xs  text-[#667085] mb-2">
                  <span>Year 02 (2024)</span>
                  <span className="text-[#3155D9] font-bold">Completed</span>
                </div>
                <h5 className="text-sm font-bold text-[#182033]">Intermediate Finance & Law</h5>
                <p className="text-xs text-[#667085] mt-1.5 leading-relaxed">
                  Commercial law, corporate finance theory, macroeconomics, business communication, and institutional systems.
                </p>
              </div>

              {/* Year 3 (Current) */}
              <div className="p-4 rounded-xl bg-white border-2 border-[#3155D9] shadow-sm">
                <div className="flex items-center justify-between text-xs  text-[#3155D9] mb-2 font-bold">
                  <span>Year 03 (Current)</span>
                  <span className="px-2 py-0.5 rounded bg-[#E9EEFF] text-[#3155D9] text-[10px] font-bold">Active</span>
                </div>
                <h5 className="text-sm font-bold text-[#182033]">Specialized Discipline Core</h5>
                <p className="text-xs text-[#667085] mt-1.5 leading-relaxed">
                  Auditing (4.00 A+), Working Capital Management, Money & Monetary Policy, Cost Accounting, and Investment Banking.
                </p>
              </div>

              {/* Year 4 (Upcoming) */}
              <div className="p-4 rounded-xl bg-white border border-[#E3E8F5] shadow-2xs opacity-85">
                <div className="flex items-center justify-between text-xs  text-[#667085] mb-2">
                  <span>Year 04 (2026–2027)</span>
                  <span className="font-medium text-[#667085]">Target</span>
                </div>
                <h5 className="text-sm font-bold text-[#182033]">Advanced Electives & Thesis</h5>
                <p className="text-xs text-[#667085] mt-1.5 leading-relaxed">
                  International finance, portfolio management, applied financial research, and degree defense completion.
                </p>
              </div>

            </div>
          </div>

          {/* Bottom Card Footer */}
          <div className="mt-8 pt-6 border-t border-[#E3E8F5] flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs  text-[#667085]">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#3155D9]" />
              <span>Full compliance with UGC Bangladesh degree specifications and UGC grading matrix.</span>
            </div>
            <span className="text-[#667085]">Graduation Target: 2027</span>
          </div>

        </div>

      </div>
    </section>
  );
};
