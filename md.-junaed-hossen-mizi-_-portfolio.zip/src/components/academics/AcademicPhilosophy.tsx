import React from 'react';
import { Quote, Sparkles, TrendingUp, ShieldCheck, Compass } from 'lucide-react';

export const AcademicPhilosophy: React.FC = () => {
  return (
    <section className="py-24 md:py-32 bg-[#FAFBFF] border-t border-[#E3E8F5] relative overflow-hidden">
      
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        
        {/* Label */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E9EEFF] border border-[#3155D9]/20 text-xs  text-[#3155D9] uppercase tracking-wider mb-6 shadow-2xs font-semibold">
          <Sparkles className="w-3.5 h-3.5 text-[#3155D9]" />
          <span>Core Academic Conviction</span>
        </div>

        {/* Big Memorable Heading */}
        <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-serif font-bold tracking-tight text-[#182033] max-w-3xl mx-auto leading-tight">
          "Learning Is a Long-Term Investment."
        </h2>

        {/* Visual Divider with Cobalt */}
        <div className="my-8 flex items-center justify-center gap-3">
          <div className="w-12 h-px bg-gradient-to-r from-transparent to-[#3155D9]/40" />
          <div className="w-2 h-2 rounded-full bg-[#3155D9]" />
          <div className="w-12 h-px bg-gradient-to-l from-transparent to-[#3155D9]/40" />
        </div>

        {/* Philosophy Statement */}
        <p className="text-lg sm:text-xl md:text-2xl text-[#667085] max-w-3xl mx-auto leading-relaxed font-normal italic font-serif">
          "I see education not simply as a way to earn grades, but as a foundation for better decisions, stronger professional skills, meaningful research, and long-term impact."
        </p>

        {/* Supporting Pillars in Minimalist Badges */}
        <div className="mt-12 flex flex-wrap items-center justify-center gap-4 text-xs  text-[#182033]">
          <div className="px-4 py-2 rounded-xl bg-white border border-[#E3E8F5] flex items-center gap-2 shadow-2xs">
            <span className="w-1.5 h-1.5 rounded-full bg-[#3155D9]" />
            <span className="font-semibold">Analytical Truth & Rigor</span>
          </div>
          <div className="px-4 py-2 rounded-xl bg-white border border-[#E3E8F5] flex items-center gap-2 shadow-2xs">
            <span className="w-1.5 h-1.5 rounded-full bg-[#3155D9]" />
            <span className="font-semibold">Ethical Financial Stewardship</span>
          </div>
          <div className="px-4 py-2 rounded-xl bg-white border border-[#E3E8F5] flex items-center gap-2 shadow-2xs">
            <span className="w-1.5 h-1.5 rounded-full bg-[#3155D9]" />
            <span className="font-semibold">Enduring Professional Discipline</span>
          </div>
        </div>

        <div className="mt-8 text-xs  text-[#667085]">
          Md. Junaed Hossen Mizi • Department of Finance and Banking, BRUR
        </div>

      </div>
    </section>
  );
};
