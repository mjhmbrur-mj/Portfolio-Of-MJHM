import React from 'react';
import { ArrowLeft, BookOpen, Sparkles, GraduationCap, Compass, ShieldCheck } from 'lucide-react';
import { academicProfile } from '../../data/academicAchievementsData';

interface AcademicHeroProps {
  onBackToPortfolio: () => void;
}

export const AcademicHero: React.FC<AcademicHeroProps> = ({ onBackToPortfolio }) => {
  return (
    <section className="relative pt-24 pb-16 md:pt-32 md:pb-24 overflow-hidden border-b border-[#E3E8F5] bg-white">
      {/* Background Academic Grid & Mathematical Atmosphere */}
      <div 
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(to right, #3155D9 1px, transparent 1px),
            linear-gradient(to bottom, #3155D9 1px, transparent 1px)
          `,
          backgroundSize: '48px 48px',
        }}
      />

      {/* Floating Mathematical / Financial Formulas & Notations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none select-none text-[11px]  text-[#3155D9]/15">
        <span className="absolute top-28 left-[8%] hidden md:block">
          CAPM: E(R_i) = R_f + \beta_i[E(R_m) - R_f]
        </span>
        <span className="absolute top-44 right-[10%] hidden md:block">
          WACC = (E/V \cdot Re) + (D/V \cdot Rd \cdot [1 - Tc])
        </span>
        <span className="absolute bottom-20 left-[12%] hidden lg:block">
          CCC = DIO + DSO - DPO
        </span>
        <span className="absolute bottom-16 right-[15%] hidden lg:block">
          ROIC = NOPAT / Invested Capital
        </span>
        <span className="absolute top-64 left-[4%] hidden xl:block">
          {"NPV = \\sum_{t=0}^{n} \\frac{CF_t}{(1+r)^t}"}
        </span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Navigation Breadcrumb / Back Link */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <button
            type="button"
            onClick={onBackToPortfolio}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-[#FAFBFF] border border-[#E3E8F5] hover:border-[#3155D9]/40 text-xs  text-[#667085] hover:text-[#3155D9] transition-all cursor-pointer group shadow-2xs"
          >
            <ArrowLeft className="w-3.5 h-3.5 text-[#3155D9] group-hover:-translate-x-1 transition-transform" />
            <span>Back to Main Portfolio</span>
          </button>

          <div className="flex items-center gap-2 text-xs  text-[#667085]">
            <span className="px-2.5 py-1 rounded-lg bg-[#E9EEFF] border border-[#3155D9]/20 text-[#3155D9] font-medium">
              {academicProfile.university}
            </span>
            <span className="hidden sm:inline">•</span>
            <span className="hidden sm:inline text-[#667085] ">
              Session {academicProfile.session}
            </span>
          </div>
        </div>

        {/* Small Label */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E9EEFF] border border-[#3155D9]/20 text-xs  text-[#3155D9] uppercase tracking-wider mb-4 font-semibold">
          <GraduationCap className="w-3.5 h-3.5" />
          <span>ACADEMIC JOURNEY</span>
        </div>

        {/* Main Heading */}
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-bold tracking-tight text-[#182033] max-w-4xl">
          Academic Achievements.
        </h1>

        {/* Supporting Text */}
        <p className="text-lg sm:text-xl font-serif italic text-[#3155D9] mt-6 max-w-3xl leading-relaxed">
          "Every milestone reflects a continuous journey of learning, discipline, curiosity, and professional growth."
        </p>

        {/* Institutional Affiliation Bar */}
        <div className="mt-8 pt-6 border-t border-[#E3E8F5] flex flex-wrap items-center gap-y-3 gap-x-6 text-xs text-[#667085] ">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
            <span className="text-[#182033] font-semibold">{academicProfile.degreeTitle}</span>
          </div>
          <div>•</div>
          <div>{academicProfile.department}</div>
          <div>•</div>
          <div>Curriculum Scale: {academicProfile.curriculumScale}</div>
          <div>•</div>
          <div className="text-[#3155D9] font-semibold">ICAB Chartered Accountancy Track</div>
        </div>

      </div>
    </section>
  );
};
