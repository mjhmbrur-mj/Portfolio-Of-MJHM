import React, { useState } from 'react';
import { X, CheckCircle2, PieChart } from 'lucide-react';
import { ProjectItem } from '../types';

interface ProjectDetailModalProps {
  project: ProjectItem | null;
  onClose: () => void;
}

export const ProjectDetailModal: React.FC<ProjectDetailModalProps> = ({ project, onClose }) => {
  if (!project) return null;

  const [budgetMultiplier, setBudgetMultiplier] = useState<number>(500000); // 5 Lakh default

  const formatBDT = (amount: number) => {
    return `BDT ${(amount / 100000).toFixed(2)} Lakh (${amount.toLocaleString('en-BD')})`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-[#182033]/60 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Modal Card */}
      <div className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl bg-white border border-[#E3E8F5] shadow-2xl p-6 sm:p-8 z-10 text-[#182033]">
        
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-[#FAFBFF] text-[#667085] hover:text-[#182033] border border-[#E3E8F5] hover:border-[#3155D9] transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header Badges */}
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <span className=" text-xs text-[#3155D9] px-2.5 py-0.5 rounded-md bg-[#E9EEFF] border border-[#3155D9]/20 font-semibold">
            {project.status}
          </span>
          <span className=" text-xs text-[#667085] px-2.5 py-0.5 rounded-md bg-[#FAFBFF] border border-[#E3E8F5]">
            Role: {project.role}
          </span>
          {project.achievement && (
            <span className=" text-xs text-[#3155D9] px-2.5 py-0.5 rounded-md bg-[#E9EEFF] border border-[#3155D9]/30 font-medium">
              {project.achievement}
            </span>
          )}
        </div>

        {/* Title & Tagline */}
        <h2 className="font-serif text-2xl sm:text-3xl font-bold tracking-tight text-[#182033]">
          {project.title}
        </h2>
        <p className="font-sans text-sm text-[#667085] mt-1">
          {project.tagline}
        </p>

        {/* Description */}
        <div className="my-5 p-4 rounded-xl bg-[#FAFBFF] border border-[#E3E8F5] text-sm text-[#182033]/85 leading-relaxed font-sans">
          {project.description}
        </div>

        {/* Haatkotha: Interactive Financial Allocation Visualizer */}
        {project.budgetConcept && (
          <div className="my-6 p-5 rounded-xl bg-[#FAFBFF] border border-[#E3E8F5]">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 pb-3 border-b border-[#E3E8F5]">
              <div className="flex items-center gap-2">
                <PieChart className="w-4 h-4 text-[#3155D9]" />
                <h3 className="font-serif text-base font-bold text-[#182033]">
                  Financial Allocation Model
                </h3>
              </div>
              <div className="text-xs  text-[#667085]">
                Baseline: <span className="text-[#3155D9] font-medium">{project.budgetConcept.total}</span>
              </div>
            </div>

            {/* Interactive Slider */}
            <div className="mb-5 p-3.5 rounded-lg bg-white border border-[#E3E8F5]">
              <div className="flex items-center justify-between text-xs  text-[#667085] mb-2">
                <span>Budget Simulation Scale:</span>
                <span className="text-[#3155D9] font-semibold">{formatBDT(budgetMultiplier)}</span>
              </div>
              <input
                type="range"
                min="300000"
                max="1500000"
                step="50000"
                value={budgetMultiplier}
                onChange={(e) => setBudgetMultiplier(Number(e.target.value))}
                className="w-full accent-[#3155D9] cursor-pointer"
              />
              <div className="flex justify-between text-[10px]  text-[#667085] mt-1">
                <span>BDT 3 Lakh (Pilot)</span>
                <span>BDT 5 Lakh (Proposal)</span>
                <span>BDT 15 Lakh (Scale)</span>
              </div>
            </div>

            {/* Visual Allocation Bar */}
            <div className="w-full h-3 rounded-full overflow-hidden flex bg-[#E3E8F5] mb-5">
              {project.budgetConcept.breakdown.map((item, i) => (
                <div
                  key={i}
                  style={{ width: `${item.percentage}%`, backgroundColor: item.color }}
                  title={`${item.category}: ${item.percentage}%`}
                />
              ))}
            </div>

            {/* Breakdown Table */}
            <div className="space-y-2">
              {project.budgetConcept.breakdown.map((item, idx) => {
                const simulatedAmount = (budgetMultiplier * item.percentage) / 100;
                return (
                  <div
                    key={idx}
                    className="p-2.5 rounded-lg bg-white border border-[#E3E8F5] flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: item.color }}
                      />
                      <span className="font-sans font-semibold text-[#182033]">{item.category}</span>
                      <span className="text-[11px] text-[#667085] hidden sm:inline">— {item.purpose}</span>
                    </div>
                    <div className="text-right shrink-0  text-xs">
                      <span className="text-[#3155D9] font-bold mr-2">
                        {item.percentage}%
                      </span>
                      <span className="text-[#667085]">
                        BDT {(simulatedAmount / 100000).toFixed(2)}L
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Features / Modules List for CA Mock Platform */}
        {project.features && (
          <div className="my-5">
            <h3 className=" text-xs uppercase tracking-wider text-[#667085] mb-2.5 font-semibold">
              Architectural Capabilities & Features
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {project.features.map((feat, i) => (
                <div
                  key={i}
                  className="p-2.5 rounded-lg bg-[#FAFBFF] border border-[#E3E8F5] flex items-start gap-2 text-xs font-sans text-[#182033]"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#3155D9] shrink-0 mt-0.5" />
                  <span>{feat}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Educational Series for Finance Lab */}
        {project.educationalSeries && (
          <div className="my-5">
            <h3 className=" text-xs uppercase tracking-wider text-[#667085] mb-2.5 font-semibold">
              Curated Educational Content
            </h3>
            <div className="space-y-1.5">
              {project.educationalSeries.map((series, i) => (
                <div
                  key={i}
                  className="p-2.5 rounded-lg bg-[#FAFBFF] border border-[#E3E8F5] text-xs font-sans text-[#182033] flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <span className=" text-[11px] text-[#3155D9] font-bold">0{i + 1}</span>
                    <span>{series}</span>
                  </div>
                  <span className=" text-[10px] text-[#667085]">Analytical Resource</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Strategic Pillars */}
        <div className="mt-5 pt-4 border-t border-[#E3E8F5]">
          <h4 className=" text-xs uppercase tracking-wider text-[#667085] mb-2 font-semibold">
            Strategic Value Pillars
          </h4>
          <div className="flex flex-wrap gap-1.5">
            {project.keyPillars.map((pillar, pIdx) => (
              <span
                key={pIdx}
                className="px-2.5 py-1 rounded text-xs  bg-[#FAFBFF] border border-[#E3E8F5] text-[#182033]"
              >
                {pillar}
              </span>
            ))}
          </div>
        </div>

        {/* Footer info */}
        <div className="mt-6 pt-4 border-t border-[#E3E8F5] flex items-center justify-between text-xs  text-[#667085]">
          <span>Audience: {project.targetAudience || 'Students & Finance Learners'}</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-[#3155D9] hover:bg-[#2444B8] text-white font-medium transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
