import React, { useState } from 'react';
import { 
  MapPin, 
  Copy, 
  Check, 
  Send, 
  ArrowUpRight,
  Linkedin,
  Facebook,
  Github
} from 'lucide-react';
import { profileData } from '../data/portfolioData';

export const Contact: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(profileData.contact.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;
    setFormSubmitted(true);
  };

  return (
    <section id="contact" className="py-20 md:py-28 bg-[#FAFBFF] text-[#182033] border-b border-[#E3E8F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-14">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
            <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
              DIALOGUE & INQUIRY
            </span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#182033]">
            Let's Connect
          </h2>
          <p className="font-sans text-sm sm:text-base text-[#667085] mt-3">
            Open to discussions around banking asset quality, finance research, competition cases, academic initiatives, and professional opportunities.
          </p>
        </div>

        {/* Contact Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Left Column: Direct Coordinates & Social Links */}
          <div className="lg:col-span-5 space-y-6">
            {/* Primary Email Card */}
            <div className="p-6 rounded-2xl bg-white border border-[#E3E8F5] shadow-xs">
              <span className=" text-xs text-[#667085] uppercase tracking-wider block font-medium">
                Direct Email
              </span>
              <div className="mt-2 flex items-center justify-between gap-3">
                <a
                  href={`mailto:${profileData.contact.email}`}
                  className="text-base sm:text-lg  text-[#182033] hover:text-[#3155D9] font-medium transition-colors break-all"
                >
                  {profileData.contact.email}
                </a>
                <button
                  type="button"
                  onClick={handleCopyEmail}
                  className="p-2.5 rounded-lg bg-[#FAFBFF] hover:bg-[#E9EEFF] text-[#667085] hover:text-[#3155D9] border border-[#E3E8F5] hover:border-[#3155D9]/30 transition-colors shrink-0 cursor-pointer"
                  title="Copy email to clipboard"
                  aria-label="Copy email address"
                >
                  {copied ? (
                    <Check className="w-4 h-4 text-[#3155D9]" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>
              {copied && (
                <p className="text-xs text-[#3155D9]  mt-2 flex items-center gap-1 font-medium">
                  <Check className="w-3.5 h-3.5" />
                  Copied to clipboard
                </p>
              )}
            </div>

            {/* Academic Base Card */}
            <div className="p-6 rounded-2xl bg-white border border-[#E3E8F5] shadow-xs flex items-start gap-3.5">
              <MapPin className="w-4 h-4 text-[#3155D9] shrink-0 mt-1" />
              <div>
                <h4 className="font-sans text-sm font-bold text-[#182033]">Academic Base</h4>
                <p className="font-sans text-xs text-[#667085] mt-0.5">
                  Begum Rokeya University, Rangpur (BRUR)
                </p>
                <p className=" text-[11px] text-[#3155D9] mt-0.5 font-medium">
                  Rangpur & Chandpur, Bangladesh
                </p>
              </div>
            </div>

            {/* Professional Networks */}
            <div>
              <h4 className=" text-xs uppercase tracking-wider text-[#667085] font-semibold mb-3">
                Online Profiles
              </h4>
              <div className="space-y-2.5">
                <a
                  href={profileData.contact.linkedin}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3.5 rounded-xl bg-white border border-[#E3E8F5] hover:border-[#3155D9] flex items-center justify-between text-xs text-[#182033] shadow-2xs hover:shadow-sm transition-all group"
                >
                  <div className="flex items-center gap-2.5">
                    <Linkedin className="w-4 h-4 text-[#3155D9]" />
                    <span className="font-medium">LinkedIn Profile</span>
                  </div>
                  <span className=" text-[11px] text-[#667085] group-hover:text-[#3155D9] flex items-center gap-1 transition-colors">
                    Connect <ArrowUpRight className="w-3.5 h-3.5 text-[#3155D9]" />
                  </span>
                </a>

                <a
                  href={profileData.contact.facebook}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3.5 rounded-xl bg-white border border-[#E3E8F5] hover:border-[#3155D9] flex items-center justify-between text-xs text-[#182033] shadow-2xs hover:shadow-sm transition-all group"
                >
                  <div className="flex items-center gap-2.5">
                    <Facebook className="w-4 h-4 text-[#3155D9]" />
                    <span className="font-medium">Facebook Profile</span>
                  </div>
                  <span className=" text-[11px] text-[#667085] group-hover:text-[#3155D9] flex items-center gap-1 transition-colors">
                    View <ArrowUpRight className="w-3.5 h-3.5 text-[#3155D9]" />
                  </span>
                </a>

                <a
                  href={profileData.contact.github}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3.5 rounded-xl bg-white border border-[#E3E8F5] hover:border-[#3155D9] flex items-center justify-between text-xs text-[#182033] shadow-2xs hover:shadow-sm transition-all group"
                >
                  <div className="flex items-center gap-2.5">
                    <Github className="w-4 h-4 text-[#3155D9]" />
                    <span className="font-medium">GitHub Profile</span>
                  </div>
                  <span className=" text-[11px] text-[#667085] group-hover:text-[#3155D9] flex items-center gap-1 transition-colors">
                    Repositories <ArrowUpRight className="w-3.5 h-3.5 text-[#3155D9]" />
                  </span>
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Inquiry Form */}
          <div className="lg:col-span-7">
            <div className="p-6 sm:p-8 rounded-2xl bg-white border border-[#E3E8F5] shadow-xs">
              <h3 className="font-serif text-xl font-bold text-[#182033]">
                Send a Message
              </h3>
              <p className="font-sans text-xs text-[#667085] mt-1">
                Reach out for research discussions, academic inquiries, or case study collaboration.
              </p>

              {formSubmitted ? (
                <div className="my-6 p-8 rounded-2xl bg-[#FAFBFF] border border-[#3155D9]/30 text-center">
                  <div className="w-12 h-12 rounded-full bg-[#E9EEFF] text-[#3155D9] flex items-center justify-center mx-auto mb-3">
                    <Check className="w-6 h-6" />
                  </div>
                  <h4 className="font-serif text-lg font-bold text-[#182033]">
                    Message Received
                  </h4>
                  <p className="font-sans text-xs text-[#667085] mt-1.5 max-w-sm mx-auto leading-relaxed">
                    Thank you. Md. Junaed Hossen Mizi will review your message and reply via {profileData.contact.email}.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setFormSubmitted(false);
                      setFormData({ name: '', email: '', subject: '', message: '' });
                    }}
                    className="mt-5 px-4 py-2 rounded-lg bg-[#FAFBFF] hover:bg-[#E9EEFF] text-xs  text-[#3155D9] border border-[#E3E8F5] hover:border-[#3155D9]/30 transition-colors font-medium cursor-pointer"
                  >
                    Send Another Note
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="mt-5 space-y-4 font-sans">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs  text-[#667085] mb-1 font-medium">
                        Your Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g. Professor, Analyst, Peer"
                        className="w-full px-3.5 py-2.5 rounded-lg bg-[#FAFBFF] border border-[#E3E8F5] focus:border-[#3155D9] focus:bg-white text-sm text-[#182033] placeholder-[#667085]/60 outline-none transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block text-xs  text-[#667085] mb-1 font-medium">
                        Your Email *
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="name@organization.com"
                        className="w-full px-3.5 py-2.5 rounded-lg bg-[#FAFBFF] border border-[#E3E8F5] focus:border-[#3155D9] focus:bg-white text-sm text-[#182033] placeholder-[#667085]/60 outline-none transition-colors"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs  text-[#667085] mb-1 font-medium">
                      Subject
                    </label>
                    <input
                      type="text"
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      placeholder="e.g. Academic Inquiry / Research Exchange"
                      className="w-full px-3.5 py-2.5 rounded-lg bg-[#FAFBFF] border border-[#E3E8F5] focus:border-[#3155D9] focus:bg-white text-sm text-[#182033] placeholder-[#667085]/60 outline-none transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs  text-[#667085] mb-1 font-medium">
                      Message *
                    </label>
                    <textarea
                      rows={4}
                      required
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Write your note, question, or discussion topics..."
                      className="w-full px-3.5 py-2.5 rounded-lg bg-[#FAFBFF] border border-[#E3E8F5] focus:border-[#3155D9] focus:bg-white text-sm text-[#182033] placeholder-[#667085]/60 outline-none transition-colors resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    id="contact-submit-button"
                    className="w-full py-3 px-4 rounded-xl text-xs  font-semibold bg-[#3155D9] hover:bg-[#2444B8] text-white shadow-md shadow-[#3155D9]/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Send Message</span>
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </form>
              )}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
