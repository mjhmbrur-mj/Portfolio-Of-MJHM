import React from 'react';
import { currentlyItems } from '../data/portfolioData';

export const Currently: React.FC = () => {
  return (
    <section className="py-12 bg-[#FAFBFF] border-b border-[#E3E8F5] text-[#182033]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-baseline justify-between gap-3 mb-8">
          <div>
            <div className="flex items-center gap-2 text-xs  text-[#3155D9] uppercase tracking-wider font-semibold mb-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#3155D9]" />
              <span>LIVE TRAJECTORY</span>
            </div>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#182033] tracking-tight">
              Currently Active Pursuits
            </h2>
          </div>
          <p className="font-sans text-xs sm:text-sm text-[#667085] max-w-md">
            Continuous development across university coursework, ICAB professional studies, and applied financial research.
          </p>
        </div>

        {/* 6 Responsive Live Status Cards with hairline borders */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {currentlyItems.map((item) => (
            <div
              key={item.id}
              className="p-5 rounded-xl bg-white border border-[#E3E8F5] hover:border-[#3155D9]/50 hover:shadow-sm transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className=" text-[11px] text-[#3155D9] font-medium uppercase tracking-wider">
                    {item.status}
                  </span>
                  <span className="w-2 h-2 rounded-full bg-[#3155D9] animate-pulse" />
                </div>
                <h3 className="font-sans text-sm font-semibold text-[#182033] leading-snug">
                  {item.title}
                </h3>
                <p className="font-sans text-xs text-[#667085] mt-1.5 leading-relaxed">
                  {item.subtitle}
                </p>
              </div>

              {item.highlight && (
                <div className="mt-4 pt-3 border-t border-[#E3E8F5] flex items-center justify-between text-[11px]  text-[#667085]">
                  <span>{item.highlight}</span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
