import React, { useState } from 'react';
import { skillCategoriesData } from '../data/portfolioData';

export const Skills: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>(skillCategoriesData[0].id);

  const currentCategory = skillCategoriesData.find((cat) => cat.id === activeCategory) || skillCategoriesData[0];

  const getLevelBadge = (level: string) => {
    switch (level) {
      case 'Core Academic Focus':
        return 'bg-[#E9EEFF] text-[#3155D9] border-[#3155D9]/20 font-semibold';
      case 'Practical Competence':
        return 'bg-[#FAFBFF] text-[#182033] border-[#E3E8F5] font-medium';
      case 'Active Development':
        return 'bg-white text-[#667085] border-[#E3E8F5]';
      default:
        return 'bg-white text-[#667085] border-[#E3E8F5]';
    }
  };

  return (
    <section id="skills" className="py-20 md:py-28 bg-[#FAFBFF] text-[#182033] border-b border-[#E3E8F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-12">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
            <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
              CAPABILITY MATRIX
            </span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#182033]">
            Skills & Competencies
          </h2>
          <p className="font-sans text-sm sm:text-base text-[#667085] mt-3 leading-relaxed">
            Cultivated through active undergraduate coursework, professional ICAB chartered accountancy training, competitive pitching, and empirical research tools.
          </p>
        </div>

        {/* Category Navigation Tabs */}
        <div className="flex flex-wrap gap-2 pb-6 border-b border-[#E3E8F5]">
          {skillCategoriesData.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3.5 py-1.5 rounded-lg text-xs  transition-all duration-150 cursor-pointer ${
                activeCategory === cat.id
                  ? 'bg-[#3155D9] text-white font-medium shadow-xs'
                  : 'bg-white text-[#667085] hover:text-[#182033] border border-[#E3E8F5]'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Category Overview */}
        <div className="py-6 flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
          <div>
            <h3 className="font-serif text-xl font-bold text-[#182033]">
              {currentCategory.name}
            </h3>
            <p className="font-sans text-xs sm:text-sm text-[#667085] mt-1">
              {currentCategory.description}
            </p>
          </div>
          <span className=" text-xs text-[#3155D9] font-medium">
            Academic & practical calibration
          </span>
        </div>

        {/* Skills Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {currentCategory.skills.map((skill, idx) => (
            <div
              key={idx}
              className="p-5 rounded-xl bg-white border border-[#E3E8F5] hover:border-[#3155D9] transition-all duration-150 shadow-xs hover:shadow-md hover:shadow-[#3155D9]/5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <h4 className="font-sans text-sm font-bold text-[#182033]">
                    {skill.name}
                  </h4>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px]  whitespace-nowrap border ${getLevelBadge(
                      skill.level
                    )}`}
                  >
                    {skill.level}
                  </span>
                </div>
                <p className="font-sans text-xs text-[#667085] leading-relaxed">
                  {skill.context}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-[#E3E8F5] flex items-center justify-between text-[11px]  text-[#667085]">
                <span>Applied Field</span>
                <span className="text-[#3155D9] font-medium">Verified</span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
