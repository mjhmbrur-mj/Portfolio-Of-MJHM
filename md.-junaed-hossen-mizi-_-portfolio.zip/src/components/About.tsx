import React from 'react';
import { profileData } from '../data/portfolioData';

export const About: React.FC = () => {
  const snapshotCards = [
    {
      label: "Degree & Department",
      value: profileData.degree,
      subvalue: profileData.department,
      badge: "Session 2022–2023",
    },
    {
      label: "Professional Track",
      value: profileData.professionalEducation.stage,
      subvalue: profileData.professionalEducation.institute,
      badge: "Chartered Accountancy",
    },
    {
      label: "University",
      value: profileData.university,
      subvalue: "Rangpur, Bangladesh",
      badge: "Public University",
    },
    {
      label: "Academic Focus",
      value: "Finance, Accounting & Valuation",
      subvalue: "Financial analysis & market mechanics",
      badge: "Core Discipline",
    },
    {
      label: "Current CGPA",
      value: "3.67 / 4.00",
      subvalue: `Most recent SGPA: ${profileData.recentSgpa}`,
      badge: "Merit Standing",
    },
    {
      label: "Timeline",
      value: profileData.expectedGraduation,
      subvalue: "4-Year BBA Program",
      badge: "Undergraduate",
    },
  ];

  return (
    <section id="about" className="py-20 md:py-28 bg-white text-[#182033] border-b border-[#E3E8F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-14">
          <div className="flex items-center gap-2 mb-3">
            <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
            <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
              PROFILE & ORIENTATION
            </span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#182033] leading-tight">
            Curiosity, rigor, and a commitment to understanding financial systems.
          </h2>
        </div>

        {/* Narrative Grid: Two-column editorial layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Narrative Text */}
          <div className="lg:col-span-6 space-y-6 font-sans text-base sm:text-lg text-[#182033] leading-relaxed">
            <p>
              I am an undergraduate student in the <strong className="font-semibold text-[#182033]">Department of Finance and Banking</strong> at <strong className="font-semibold text-[#182033]">Begum Rokeya University, Rangpur (BRUR)</strong>. My academic journey is shaped by a deep curiosity about how capital flows, how organizations make investment decisions, and how rigorous financial reporting protects businesses.
            </p>

            <p className="text-[#667085]">
              Recognizing that strong financial professionals need both strategic market comprehension and procedural accounting rigor, I am concurrently pursuing the <span className="font-semibold text-[#3155D9]">Institute of Chartered Accountants of Bangladesh (ICAB)</span> qualification at the <span className="font-medium text-[#182033]">Certificate Level</span>. This dual focus builds a solid grounding in financial analysis, taxation, and corporate governance.
            </p>

            <p className="text-[#667085]">
              Beyond coursework, I value active contribution. Whether serving as <strong className="font-semibold text-[#182033]">Class Representative</strong>, managing financial projections as <strong className="font-semibold text-[#182033]">CFO for our Hult Prize runner-up initiative</strong>, or studying monetary data from Bangladesh Bank publications, I treat finance as an empirical, practical discipline with real human consequences.
            </p>

            {/* Editorial blockquote with cobalt accent */}
            <div className="p-5 rounded-xl bg-[#FAFBFF] border border-[#E3E8F5] border-l-2 border-l-[#3155D9]">
              <span className=" text-xs uppercase tracking-wider text-[#3155D9] font-medium block mb-1">
                Direction & Intent
              </span>
              <p className="font-sans text-sm text-[#182033] leading-relaxed italic">
                "My focus is on mastering financial fundamentals, advancing through professional accounting examinations, and developing the analytical maturity to help organizations make disciplined, high-integrity financial decisions."
              </p>
            </div>
          </div>

          {/* Right Column: Editorial Snapshot Cards */}
          <div className="lg:col-span-6">
            <div className="p-6 sm:p-7 rounded-2xl bg-[#FAFBFF] border border-[#E3E8F5] shadow-xs">
              <div className="flex items-center justify-between pb-5 mb-5 border-b border-[#E3E8F5]">
                <div>
                  <h3 className="font-serif text-lg font-bold text-[#182033]">
                    Academic Parameters
                  </h3>
                  <p className=" text-xs text-[#667085] mt-0.5">
                    BRUR Department of Finance & Banking
                  </p>
                </div>
                <span className=" text-xs px-2.5 py-1 rounded-md bg-[#E9EEFF] text-[#3155D9] font-semibold border border-[#3155D9]/20">
                  2026 Status
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {snapshotCards.map((card, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl bg-white border border-[#E3E8F5] hover:border-[#3155D9]/40 transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className=" text-[10px] text-[#3155D9] bg-[#E9EEFF] px-2 py-0.5 rounded font-medium uppercase tracking-wider">
                          {card.badge}
                        </span>
                      </div>
                      <span className=" text-xs text-[#667085] block">
                        {card.label}
                      </span>
                      <h4 className="font-sans text-sm font-bold text-[#182033] mt-0.5 leading-snug">
                        {card.value}
                      </h4>
                    </div>
                    <p className="font-sans text-xs text-[#667085] mt-2 leading-tight">
                      {card.subvalue}
                    </p>
                  </div>
                ))}
              </div>

              {/* Verified distinction footer */}
              <div className="mt-5 pt-4 border-t border-[#E3E8F5] flex items-center justify-between  text-xs text-[#667085]">
                <span className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#3155D9]" />
                  <span className="text-[#182033] font-medium">Govt. Board Scholarship Recipient</span>
                </span>
                <span className="text-[#3155D9] font-medium">SSC & HSC GPA 5.00</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
