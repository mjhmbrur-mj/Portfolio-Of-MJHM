import React from 'react';
import { ArrowUp, Linkedin, Facebook, Github, Mail } from 'lucide-react';
import { profileData } from '../data/portfolioData';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const footerLinks = [
    { label: 'About', href: '#about' },
    { label: 'The Numbers', href: '#numbers' },
    { label: 'Journey', href: '#journey' },
    { label: 'Education', href: '#education' },
    { label: 'Academics', href: '#academics' },
    { label: 'Projects', href: '#projects' },
    { label: 'Research', href: '#research' },
    { label: 'Finance Lab', href: '#writing' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <footer className="bg-[#2444B8] border-t border-[#3155D9] pt-16 pb-12 text-[#E9EEFF] text-xs">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Tier: Monogram & Identity */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-10 border-b border-white/15">
          <div>
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#3155D9] border border-white/25 flex items-center justify-center font-serif font-bold text-sm text-white shadow-sm">
                {profileData.initials}
              </div>
              <div>
                <h3 className="font-serif text-base font-bold text-white">
                  {profileData.name}
                </h3>
                <p className="text-xs  text-[#E9EEFF]/80">
                  Finance & Banking | ICAB CA Student | BRUR
                </p>
              </div>
            </div>
            <p className="font-serif italic text-xs text-white/90 mt-3">
              "Building knowledge. Creating disciplined financial impact."
            </p>
          </div>

          {/* Back to top & direct email */}
          <div className="flex items-center gap-3">
            <a
              href={`mailto:${profileData.contact.email}`}
              className="px-4 py-2 rounded-xl bg-[#3155D9] border border-white/20 hover:bg-white hover:text-[#2444B8] text-white transition-all  text-xs font-medium shadow-sm"
            >
              {profileData.contact.email}
            </a>

            <button
              type="button"
              onClick={scrollToTop}
              className="p-2.5 rounded-xl bg-[#3155D9] border border-white/20 hover:bg-white hover:text-[#2444B8] text-white transition-all cursor-pointer shadow-sm"
              aria-label="Back to top"
              title="Back to top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Middle Tier: Navigation Links & Social */}
        <div className="py-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4  text-xs">
          <div className="flex flex-wrap gap-x-5 gap-y-2">
            {footerLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-[#E9EEFF]/90 hover:text-white transition-colors"
              >
                {link.label}
              </a>
            ))}
          </div>

          <div className="flex items-center gap-4">
            <a
              href={profileData.contact.linkedin}
              target="_blank"
              rel="noreferrer"
              className="text-[#E9EEFF] hover:text-white transition-colors p-1"
              aria-label="LinkedIn Profile"
            >
              <Linkedin className="w-4 h-4" />
            </a>
            <a
              href={profileData.contact.facebook}
              target="_blank"
              rel="noreferrer"
              className="text-[#E9EEFF] hover:text-white transition-colors p-1"
              aria-label="Facebook Profile"
            >
              <Facebook className="w-4 h-4" />
            </a>
            <a
              href={profileData.contact.github}
              target="_blank"
              rel="noreferrer"
              className="text-[#E9EEFF] hover:text-white transition-colors p-1"
              aria-label="GitHub Profile"
            >
              <Github className="w-4 h-4" />
            </a>
            <a
              href={`mailto:${profileData.contact.email}`}
              className="text-[#E9EEFF] hover:text-white transition-colors p-1"
              aria-label="Email Inquiry"
            >
              <Mail className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* Bottom Tier: Copyright & Institution */}
        <div className="pt-6 border-t border-white/15 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-[#E9EEFF]/75 ">
          <p>
            © 2026 Md. Junaed Hossen Mizi. All rights reserved.
          </p>
          <p className="flex items-center gap-1.5">
            <span>Begum Rokeya University, Rangpur</span>
            <span>•</span>
            <span>ICAB Certificate Level</span>
          </p>
        </div>

      </div>
    </footer>
  );
};
