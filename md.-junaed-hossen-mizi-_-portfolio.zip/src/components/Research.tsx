import React, { useState } from 'react';
import { Database, LineChart } from 'lucide-react';
import { researchPipelineSteps, researchInterestsData } from '../data/portfolioData';

export const Research: React.FC = () => {
  const [activeStep, setActiveStep] = useState<number>(1);

  const currentStepData = researchPipelineSteps.find((s) => s.step === activeStep) || researchPipelineSteps[0];

  const dataSources = [
    { name: "World Bank Open Data", focus: "Global economic indicators, poverty, financial access indices" },
    { name: "Bangladesh Bank Publications", focus: "Scheduled bank statistics, monetary policy statements, NPL figures" },
    { name: "International Monetary Fund (IMF)", focus: "Fiscal balances, macroeconomic stability frameworks, IFS database" },
    { name: "Dhaka Stock Exchange (DSE)", focus: "Historical market turnover, sector capitalization, PE distribution" },
  ];

  return (
    <section id="research" className="py-20 md:py-28 bg-white text-[#182033] border-b border-[#E3E8F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-14">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-[#3155D9]" />
            <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
              EMPIRICAL INQUIRY & METHODOLOGY
            </span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#182033]">
            Learning to Ask Better Questions
          </h2>
          <p className="font-sans text-sm sm:text-base text-[#667085] mt-3">
            Developing disciplined research capabilities focused on banking asset quality, financial literacy, capital markets, and emerging economy dynamics.
          </p>
        </div>

        {/* Academic Honesty Banner */}
        <div className="p-6 rounded-2xl bg-[#FAFBFF] border border-[#E3E8F5] mb-14 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-xs">
          <div>
            <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold block mb-1">
              Methodological Commitment
            </span>
            <p className="font-sans text-sm text-[#182033]/85 leading-relaxed max-w-3xl">
              "Building foundational research skills with the long-term goal of producing rigorous, peer-reviewed financial research. My current focus centers on secondary data extraction, macro series interpretation, and structured hypothesis formulation."
            </p>
          </div>
          <div className=" text-xs text-[#3155D9] px-3.5 py-1.5 rounded-lg bg-[#E9EEFF] border border-[#3155D9]/20 font-medium shrink-0">
            Undergraduate Research Track
          </div>
        </div>

        {/* Secondary Research Pipeline */}
        <div className="mb-14">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-serif text-xl font-bold text-[#182033]">
                The Secondary Research Pipeline
              </h3>
              <p className=" text-xs text-[#667085] mt-0.5">
                From empirical curiosity to structured analytical insight
              </p>
            </div>
            <span className=" text-xs text-[#3155D9] font-semibold">Step {activeStep} of 6</span>
          </div>

          {/* Stepper Tabs */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 mb-4">
            {researchPipelineSteps.map((step) => (
              <button
                key={step.step}
                type="button"
                onClick={() => setActiveStep(step.step)}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  activeStep === step.step
                    ? 'bg-[#3155D9] border-[#3155D9] text-white shadow-xs'
                    : 'bg-[#FAFBFF] border-[#E3E8F5] text-[#182033] hover:border-[#3155D9]'
                }`}
              >
                <div className="flex items-center justify-between text-[11px]  mb-1">
                  <span className={activeStep === step.step ? 'text-white/80' : 'text-[#667085]'}>
                    Phase 0{step.step}
                  </span>
                </div>
                <h4 className="text-xs font-semibold truncate">
                  {step.name}
                </h4>
              </button>
            ))}
          </div>

          {/* Step Detail Display Card */}
          <div className="p-6 sm:p-7 rounded-2xl bg-[#FAFBFF] border border-[#E3E8F5]">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-4 border-b border-[#E3E8F5]">
              <div>
                <span className=" text-xs text-[#3155D9] uppercase tracking-wider font-semibold">
                  Step 0{currentStepData.step} • {currentStepData.subtitle}
                </span>
                <h4 className="font-serif text-xl font-bold text-[#182033] mt-0.5">
                  {currentStepData.name}
                </h4>
              </div>
              <span className=" text-xs text-[#667085] px-2.5 py-1 rounded bg-white border border-[#E3E8F5]">
                Standard Procedure
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h5 className=" text-xs uppercase tracking-wider text-[#667085] mb-1.5 font-semibold">
                  Procedural Approach
                </h5>
                <p className="font-sans text-xs sm:text-sm text-[#182033]/85 leading-relaxed">
                  {currentStepData.description}
                </p>
              </div>
              <div className="p-4 rounded-xl bg-white border border-[#E3E8F5]">
                <h5 className=" text-xs uppercase tracking-wider text-[#3155D9] mb-1.5 font-semibold">
                  Key Analytical Objective
                </h5>
                <p className="font-sans text-xs sm:text-sm text-[#182033]/90 leading-relaxed">
                  {currentStepData.focusArea}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* 6 Research Interests Cards */}
        <div className="mb-14">
          <h3 className="font-serif text-xl font-bold text-[#182033] mb-4">
            Core Research Focus Areas
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {researchInterestsData.map((res, idx) => (
              <div
                key={idx}
                className="p-5 rounded-2xl bg-white border border-[#E3E8F5] hover:border-[#3155D9] transition-all shadow-xs hover:shadow-md flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className=" text-[10px] uppercase tracking-wider text-[#3155D9] px-2 py-0.5 rounded-md bg-[#E9EEFF] border border-[#3155D9]/20 font-semibold">
                      Inquiry Focus 0{idx + 1}
                    </span>
                    <LineChart className="w-3.5 h-3.5 text-[#667085]" />
                  </div>
                  <h4 className="font-serif text-base font-bold text-[#182033]">
                    {res.title}
                  </h4>
                  <p className="font-sans text-xs text-[#667085] mt-2 leading-relaxed">
                    {res.description}
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-[#E3E8F5] text-[11px] ">
                  <span className="text-[#667085] block text-[10px]">Target Metric:</span>
                  <span className="text-[#182033] font-medium">{res.focusMetric}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Public Datasets Grid */}
        <div className="p-6 rounded-2xl bg-[#FAFBFF] border border-[#E3E8F5]">
          <div className="flex items-center gap-2 mb-4">
            <Database className="w-4 h-4 text-[#3155D9]" />
            <h3 className="font-serif text-base font-bold text-[#182033]">
              Primary Data Sources Consulted
            </h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {dataSources.map((source, i) => (
              <div
                key={i}
                className="p-3.5 rounded-xl bg-white border border-[#E3E8F5]"
              >
                <h4 className="font-sans text-xs font-bold text-[#182033]">{source.name}</h4>
                <p className="font-sans text-[11px] text-[#667085] mt-1 leading-snug">
                  {source.focus}
                </p>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
