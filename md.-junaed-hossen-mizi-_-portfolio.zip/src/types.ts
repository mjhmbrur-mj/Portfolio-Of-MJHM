export interface Profile {
  name: string;
  initials: string;
  primaryIdentity: string;
  headline: string;
  positioningStatement: string;
  alternativePositioning: string;
  bio: string;
  university: string;
  department: string;
  degree: string;
  session: string;
  currentStage: string;
  expectedGraduation: string;
  cgpa: string;
  recentSgpa: string;
  sscGpa: string;
  hscGpa: string;
  scholarship: string;
  professionalEducation: {
    institute: string;
    stage: string;
    qualification: string;
    note: string;
  };
  contact: {
    email: string;
    linkedin: string;
    facebook: string;
    github: string;
    location: string;
  };
}

export interface CurrentlyItem {
  id: string;
  icon: string;
  title: string;
  subtitle: string;
  status: 'In Progress' | 'Active' | 'Ongoing';
  highlight?: string;
}

export interface StatItem {
  id: string;
  value: string;
  numericValue?: number;
  suffix?: string;
  label: string;
  sublabel: string;
  description: string;
  tag: string;
}

export interface TimelineItem {
  id: string;
  year: string;
  period?: string;
  title: string;
  subtitle: string;
  category: 'academic' | 'professional' | 'leadership' | 'milestone';
  description: string;
  highlights: string[];
  skillsGained: string[];
}

export interface EducationItem {
  id: string;
  degree: string;
  institution: string;
  shortInstitution: string;
  period: string;
  score: string;
  scoreLabel: string;
  type: 'academic' | 'professional';
  details: string;
  badges: string[];
  keyCourses?: string[];
  distinction?: string;
}

export interface AcademicInterest {
  id: string;
  title: string;
  category: 'core-finance' | 'accounting-governance' | 'markets-strategy' | 'macro-research';
  summary: string;
  whyItMatters: string;
  relatedConcepts: string[];
}

export interface SkillCategory {
  id: string;
  name: string;
  description: string;
  skills: {
    name: string;
    level: 'Core Academic Focus' | 'Practical Competence' | 'Active Development' | 'Foundational';
    context: string;
  }[];
}

export interface ProjectBudgetBreakdown {
  category: string;
  percentage: number;
  amount: string;
  purpose: string;
  color: string;
}

export interface ProjectItem {
  id: string;
  title: string;
  tagline: string;
  status: 'Competition Concept' | 'Active Initiative' | 'Concept / In Development';
  role: string;
  achievement?: string;
  description: string;
  keyPillars: string[];
  tags: string[];
  budgetConcept?: {
    total: string;
    breakdown: ProjectBudgetBreakdown[];
  };
  features?: string[];
  educationalSeries?: string[];
  targetAudience?: string;
}

export interface ResearchInterest {
  title: string;
  description: string;
  focusMetric: string;
}

export interface ResearchPipelineStep {
  step: number;
  name: string;
  subtitle: string;
  description: string;
  focusArea: string;
}

export interface LeadershipRole {
  id: string;
  title: string;
  organization: string;
  period: string;
  roleType: 'Academic Coordination' | 'Competition Leadership' | 'Student Welfare & Development';
  achievement?: string;
  description: string;
  responsibilities: string[];
  impact: string;
}

export interface AchievementItem {
  id: string;
  title: string;
  organization: string;
  year: string;
  category: 'Academic' | 'Competition' | 'Global Summit' | 'Training & Fellowship';
  badge: string;
  description: string;
  significance: string;
}

export interface LabArticle {
  id: string;
  title: string;
  topic: string;
  readTime: string;
  status: 'Published' | 'Coming Soon' | 'Idea';
  summary: string;
  executiveTakeaways: string[];
  fullOutline: string;
  publishedDate?: string;
}

export interface CertificationItem {
  id: string;
  title: string;
  issuer: string;
  year: string;
  status: 'In Progress' | 'Completed' | 'Selected Participant';
  description: string;
  tags: string[];
}

export interface CareerRoadmapStep {
  phase: number;
  title: string;
  timeframe: string;
  status: 'current' | 'upcoming' | 'long-term';
  focus: string;
  milestones: string[];
  longTermContext?: string;
}

// Academic Achievements Dedicated Page Types
export interface CourseRecord {
  code: string;
  name: string;
  grade: string;
  numericGrade: number;
  letterGrade: string;
  creditHours: number;
  category: string;
  coreConcepts: string[];
  description: string;
}

export interface SemesterRecord {
  semesterNumber: number;
  title: string;
  academicYear: string;
  period: string;
  status: 'Completed' | 'Pending Records' | 'Upcoming';
  sgpa: string | null;
  cgpa: string | null;
  coursesCount?: number;
  highlights?: string;
  note?: string;
  courses?: CourseRecord[];
}

export interface AcademicProfileData {
  sscGpa: string;
  hscGpa: string;
  currentCgpa: string;
  latestSgpa: string;
  expectedGraduation: string;
  degreeTitle: string;
  department: string;
  university: string;
  session: string;
  curriculumScale: string;
}

export interface FoundationProgressionStep {
  stage: string;
  title: string;
  institution: string;
  performance: string;
  distinction?: string;
  focus: string;
  status: 'completed' | 'current' | 'future';
  iconName: string;
}

export interface ProfessionalDevelopmentRecord {
  id: string;
  title: string;
  category: 'Academic Education' | 'Professional Education' | 'Learning Programs' | 'Research Development';
  institution: string;
  status: string;
  description: string;
  distinctionNote: string;
  year: string;
}

export interface AcademicStudyArea {
  id: string;
  title: string;
  shortDescription: string;
  category: 'Finance' | 'Accounting' | 'Policy & Economics' | 'Strategy & Inquiry';
  keyQuestion: string;
}

export interface AcademicTimelineNode {
  id: string;
  period: string;
  title: string;
  subtitle: string;
  metric?: string;
  description: string;
  tags: string[];
  type: 'foundation' | 'university' | 'professional' | 'future';
}

export interface AcademicMilestoneCardData {
  id: string;
  icon: string;
  category: string;
  title: string;
  metric: string;
  description: string;
  year?: string;
  highlightColor: 'emerald' | 'gold' | 'sky' | 'amber';
}

export interface AcademicDocumentRecord {
  id: string;
  title: string;
  category: 'Marksheet' | 'Certificate' | 'Scholarship' | 'Program' | 'Credential';
  issuer: string;
  year: string;
  status: 'Verified Placeholder' | 'Available on Request' | 'Uploaded';
  description: string;
  fileType: 'PDF' | 'Official Transcript' | 'Certificate';
}

export interface AchievementDocumentItem {
  id: string;
  title: string;
  category: string; // "Academic" | "Scholarship" | "University" | "Professional Learning" | "Competitions" | "Leadership"
  year?: string;
  description: string;
  image: string;
  imageAlt: string;
  documentType?: string;
  isDocument?: boolean;
  issuer?: string;
  distinction?: string;
  privacyProtected?: boolean;
}
